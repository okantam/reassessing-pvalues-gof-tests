rm(list=ls())

options(warn = -1)

set.seed(123456789)

# Load the necessary library
library(ltmix)
library(ReIns)
data(secura)
data <- secura$size
library(SMPracticals) 
truncation_point <- 1.2e6  # Replace with your truncation point if applicable

# Fit a 1-component Lognormal mixture model
fit <- ltmm(data, G = 1, distributions = "lognormal", trunc = truncation_point)

aba <- summary(fit)

# plot(fit)

# Extract the fitted parameters
parameters <- fit$Pars

# Display the parameter estimates
# print(parameters)

# Define the lognormal PDF
lognormal_pdf <- function(x, mu, sigma) {
  dlnorm(x, meanlog = mu, sdlog = sigma)
}

# Define the lognormal CDF
lognormal_cdf <- function(x, mu, sigma) {
  plnorm(x, meanlog = mu, sdlog = sigma)
}

# Define the truncated lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (lognormal_cdf(x, mu, sigma) - lognormal_cdf(truncation_point, mu, sigma)) /
           (1 - lognormal_cdf(truncation_point, mu, sigma)))
}

# Parameters for the null model (1-component lognormal)
mu_null <- 14.3258849  # Mean of the log-transformed data
sigma_null <- 0.5014714       # Standard deviation of the log-transformed data
truncation_point <- 1.2e6

# Parameters for the alternative model
mu_alt <- 14    # Slightly shifted mean
sigma_alt <- 1

# Function to generate samples from the truncated lognormal distribution
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 50, 100, 500, 1000, 2000, 2500)
n_sims <- 2000  # Number of simulations
alpha_values <- c(0.01, 0.05, 0.1)  # List of significance levels

# Loop through each alpha value and sample size
for (alpha in alpha_values) {
  
  # Initialize data frame to store results for current alpha
  results <- data.frame(Sample_Size = integer(), Type_I_Error_Rate = numeric(), Power = numeric())
  
  # Loop through each sample size
  for (sample_size in sample_sizes) {
    
    # Initialize counters
    type_I_errors <- 0
    power_count <- 0
    
    # Type I Error Simulation: Null model
    for (i in 1:n_sims) {
      samples_null <- generate_truncated_lognormal_samples(sample_size, mu_null, sigma_null, truncation_point)
      ks_test_null <- ks.test(samples_null, function(q) truncated_lognormal_cdf(q, mu_null, sigma_null, truncation_point))
      if (ks_test_null$p.value < alpha) {
        type_I_errors <- type_I_errors + 1
      }
    }
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_truncated_lognormal_samples(sample_size, mu_alt, sigma_alt, truncation_point)
      ks_test_alt <- ks.test(samples_alt, function(q) truncated_lognormal_cdf(q, mu_null, sigma_null, truncation_point))
      if (ks_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Type I Error Rate and Power for current sample size
    type_I_error_rate <- type_I_errors / n_sims
    power <- power_count / n_sims
    
    # Store results in the data frame
    results <- rbind(results, data.frame(Sample_Size = sample_size, Type_I_Error_Rate = type_I_error_rate, Power = power))
  }
  
  # Print results for the current alpha value
  cat("\nResults for alpha =", alpha, "\n")
  print(results)
}