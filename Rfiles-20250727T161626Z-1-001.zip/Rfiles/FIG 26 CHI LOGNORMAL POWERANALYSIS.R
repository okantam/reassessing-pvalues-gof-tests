rm(list=ls())
# Load the necessary library
library(ltmix)
library(ReIns)
data(secura)
data <- secura$size
library(SMPracticals) 
truncation_point <- 1.2e6  # Replace with your truncation point if applicable

set.seed(123456789)


# Load necessary libraries
library(ggplot2)

# Lognormal CDF Function
lognormal_cdf <- function(x, mu, sigma) {
  plnorm(x, meanlog = mu, sdlog = sigma)
}

# Truncated Lognormal CDF Function
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (lognormal_cdf(x, mu, sigma) - lognormal_cdf(truncation_point, mu, sigma)) /
           (1 - lognormal_cdf(truncation_point, mu, sigma)))
}

# Function to Generate Truncated Lognormal Samples
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Dynamic Binning Function
dynamic_binning <- function(data) {
  num_bins <- max(10, floor(1 + log2(length(data))))  # Sturges' formula
  bin_edges <- quantile(data, probs = seq(0, 1, length.out = num_bins + 1))
  observed <- hist(data, breaks = bin_edges, plot = FALSE)$counts
  return(list(observed = observed, bin_edges = bin_edges))
}

# Chi-Square Test with Dynamic Binning
chi_square_test_dynamic <- function(data, cdf_func, mu, sigma, truncation_point) {
  bins <- dynamic_binning(data)
  
  expected <- sapply(1:(length(bins$bin_edges) - 1), function(i) {
    p1 <- cdf_func(bins$bin_edges[i], mu, sigma, truncation_point)
    p2 <- cdf_func(bins$bin_edges[i + 1], mu, sigma, truncation_point)
    length(data) * (p2 - p1)
  })
  
  chisq.test(bins$observed, p = expected / sum(expected), rescale.p = TRUE)
}

# Parameters for Null and Alternative Models
mu_null <- 14.3258849
sigma_null <- 0.5014714
truncation_point <- 1.2e6

mu_alt <- 14
sigma_alt <- 1

# Simulation Settings
n_sims <- 2000
alpha_values <- c(0.01, 0.05, 0.1)
step_size <- 10  # Increment in sample size

# Initialize a list to store power curve data for each alpha
power_curves <- list()

# Loop Through Each Alpha Value
for (alpha in alpha_values) {
  # Initialize variables for tracking sample size and power
  sample_size <- 10
  power <- 0
  sample_sizes <- c()
  power_values <- c()
  
  # Increment sample size until power reaches 1
  while (power < 1) {
    power_count <- 0
    
    # Power Simulation: Alternative Hypothesis
    for (i in 1:n_sims) {
      samples_alt <- generate_truncated_lognormal_samples(sample_size, mu_alt, sigma_alt, truncation_point)
      chi_sq_alt <- chi_square_test_dynamic(samples_alt, truncated_lognormal_cdf, mu_null, sigma_null, truncation_point)
      if (chi_sq_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Power for the Current Sample Size
    power <- power_count / n_sims
    
    # Store the Sample Size and Power Values
    sample_sizes <- c(sample_sizes, sample_size)
    power_values <- c(power_values, power)
    
    # Increment Sample Size if Power is Less Than 1
    if (power < 1) {
      sample_size <- sample_size + step_size
    }
  }
  
  # Store the Results for the Current Alpha Value in the List
  power_curves[[paste0("alpha_", alpha)]] <- data.frame(Sample_Size = sample_sizes, Power = power_values)
  
  # Print the Minimum Sample Size Where Power Reaches 1
  min_sample_size_power_1 <- sample_size
  cat("\nMinimum sample size where power reaches 1 for alpha =", alpha, ":", min_sample_size_power_1, "\n")
}

# Plot the Power Curves for Each Alpha
colors <- c("blue", "purple", "green")
plot(NULL, xlim = c(10, max(unlist(lapply(power_curves, function(df) df$Sample_Size)))), 
     ylim = c(0, 1), xlab = "Sample Size", ylab = "Power")

for (i in seq_along(alpha_values)) {
  alpha <- alpha_values[i]
  power_data <- power_curves[[paste0("alpha_", alpha)]]
  lines(power_data$Sample_Size, power_data$Power, col = colors[i], type = "l", lwd = 2)
  abline(h = 1, col = "red", lty = 2)  # Reference line for Power = 1
}

legend("bottomright", legend = paste("Alpha =", alpha_values), col = colors, lwd = 2)

power_curves_Chisq <- power_curves