rm(list=ls())

options(warn = -1)

set.seed(123456789)

# Load the necessary library
library(ltmix)
library(ReIns)
data(secura)
data <- secura$size
library(SMPracticals) 
truncation_point <- 1.2e6  # Replace with your truncation point if applicable

# Fit a 1-component Lognormal mixture model
fit <- ltmm(data, G = 1, distributions = "lognormal", trunc = truncation_point)

aba <- summary(fit)

# plot(fit)

# Extract the fitted parameters
parameters <- fit$Pars

# Display the parameter estimates
# print(parameters)


# Lognormal CDF Function
lognormal_cdf <- function(x, mu, sigma) {
  plnorm(x, meanlog = mu, sdlog = sigma)
}

# Truncated Lognormal CDF Function
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (lognormal_cdf(x, mu, sigma) - lognormal_cdf(truncation_point, mu, sigma)) /
           (1 - lognormal_cdf(truncation_point, mu, sigma)))
}

# Function to Generate Truncated Lognormal Samples
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Dynamic Binning Function
dynamic_binning <- function(data) {
  num_bins <- max(10, floor(1 + log2(length(data))))  # Sturges' formula
  bin_edges <- quantile(data, probs = seq(0, 1, length.out = num_bins + 1))
  observed <- hist(data, breaks = bin_edges, plot = FALSE)$counts
  return(list(observed = observed, bin_edges = bin_edges))
}

# Chi-Square Test with Dynamic Binning
chi_square_test_dynamic <- function(data, cdf_func, mu, sigma, truncation_point) {
  bins <- dynamic_binning(data)
  
  expected <- sapply(1:(length(bins$bin_edges) - 1), function(i) {
    p1 <- cdf_func(bins$bin_edges[i], mu, sigma, truncation_point)
    p2 <- cdf_func(bins$bin_edges[i + 1], mu, sigma, truncation_point)
    length(data) * (p2 - p1)
  })
  
  chisq.test(bins$observed, p = expected / sum(expected), rescale.p = TRUE)
}

# Parameters for Null and Alternative Models
mu_null <- 14.3258849
sigma_null <- 0.5014714
truncation_point <- 1.2e6

mu_alt <- 14
sigma_alt <- 1

# Simulation Settings
sample_sizes <- c(10, 50, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_values <- c(0.01, 0.05, 0.1)

# Store Results
all_results <- data.frame()

# Loop Through Each Alpha Value
for (alpha in alpha_values) {
  # Loop Through Each Sample Size
  for (sample_size in sample_sizes) {
    # Initialize Counters
    type_I_errors <- 0
    power_count <- 0
    
    # Type I Error Simulation (Null Hypothesis)
    for (i in 1:n_sims) {
      samples_null <- generate_truncated_lognormal_samples(sample_size, mu_null, sigma_null, truncation_point)
      chi_sq_null <- chi_square_test_dynamic(samples_null, truncated_lognormal_cdf, mu_null, sigma_null, truncation_point)
      if (chi_sq_null$p.value < alpha) {
        type_I_errors <- type_I_errors + 1
      }
    }
    
    # Power Simulation (Alternative Hypothesis)
    for (i in 1:n_sims) {
      samples_alt <- generate_truncated_lognormal_samples(sample_size, mu_alt, sigma_alt, truncation_point)
      chi_sq_alt <- chi_square_test_dynamic(samples_alt, truncated_lognormal_cdf, mu_null, sigma_null, truncation_point)
      if (chi_sq_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Metrics
    type_I_error_rate <- type_I_errors / n_sims
    power <- power_count / n_sims
    
    # Append Results
    all_results <- rbind(all_results, data.frame(
      Alpha = alpha,
      Sample_Size = sample_size,
      Type_I_Error_Rate = type_I_error_rate,
      Power = power
    ))
  }
}

# Print Results
print(all_results)