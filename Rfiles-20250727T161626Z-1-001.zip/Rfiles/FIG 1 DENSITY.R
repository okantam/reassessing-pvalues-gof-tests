rm(list = ls())
knitr::opts_chunk$set(echo = TRUE)
library(SMPracticals)
library(actuar)
library(ggplot2)
library(goftest)
library(gridExtra)
library(grid)
data(danish)

set.seed(123456789)

#' 
#' 
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Load necessary libraries
library(ggplot2)

# Define the Burr distribution density function
burr_pdf <- function(x, alpha, theta, gamma) {
  # Formula for the probability density function of the Burr distribution
  (alpha * gamma * (x / theta)^gamma) / (x * (1 + (x / theta)^gamma)^(alpha + 1))
}

# Function to calculate the CDF of a Burr distribution
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# Parameters for the first and second Burr components from your table
# Component 1: Burr(0.207175, 1.236993, 7.047898)
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634  # Weight for Component 1

# Component 2: Burr(0.028161, 0.856898, 50.277542)
alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 0.602366  # Weight for Component 2

# Generate a sequence of x values to plot the density
x_vals <- seq(0.01, 10, by = 0.01)

# Calculate the weighted density of each component by multiplying the density by its weight
density1 <- pi1 * burr_pdf(x_vals, alpha1, theta1, gamma1)  # Weighted Component 1 density
density2 <- pi2 * burr_pdf(x_vals, alpha2, theta2, gamma2)  # Weighted Component 2 density

# Calculate the weighted density of each component by multiplying the density by its weight
cdf1 <- pi1 * burr_cdf(x_vals, alpha1, theta1, gamma1)  # Weighted Component 1 density
cdf2 <- pi2 * burr_cdf(x_vals, alpha2, theta2, gamma2)  # Weighted Component 2 density


# Mixture density function (weighted sum of the two component densities)
mixture_density <- density1 + density2  # Combine the weighted densities

# Mixture density function (weighted sum of the two component densities)
cdfmixture_density <- cdf1 + cdf2  # Combine the weighted densities

# Create a data frame for plotting
df <- data.frame(
  x = rep(x_vals, 3),  # Repeat x values for all three distributions
  y = c(density1, density2, mixture_density),  # Combine all y values for the densities
  Distribution = factor(rep(c("1-Component", "2-Component", "Mixture"), each = length(x_vals)))
  # Define the labels for each distribution in the plot
)

# Plot the density functions of the two components and the mixture
ggplot(df, aes(x = x, y = y, color = Distribution, linetype = Distribution)) + 
  geom_line(size = 1) +  # Plot each line with the specified size
  scale_color_manual(values = c("blue", "red", "black")) +  # Assign specific colors to components
  scale_linetype_manual(values = c("dashed", "dashed", "solid")) +  # Set linetypes: dashed for components, solid for mixture
  labs(x = "x", y = "Density") +  # Set plot title and axis labels
  theme_minimal() +  # Use a minimal theme for the plot
  theme(legend.title = element_blank())  # Remove legend title for a cleaner look
