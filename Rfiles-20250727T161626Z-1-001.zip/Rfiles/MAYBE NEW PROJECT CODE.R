#' ---
#' title: "SOMETHING DIFFERENT"
#' author: "MICHAEL OKANTA"
#' date: "2024-10-24"
#' output: html_document
#' ---
#' 
## ----setup, include=FALSE--------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(SMPracticals)
library(actuar)
library(ggplot2)
library(goftest)
library(gridExtra)
library(grid)
data(danish)

set.seed(123456789)

#' 
#' 
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Load necessary libraries
library(ggplot2)

# Define the Burr distribution density function
burr_pdf <- function(x, alpha, theta, gamma) {
  # Formula for the probability density function of the Burr distribution
  (alpha * gamma * (x / theta)^gamma) / (x * (1 + (x / theta)^gamma)^(alpha + 1))
}

# Function to calculate the CDF of a Burr distribution
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# Parameters for the first and second Burr components from your table
# Component 1: Burr(0.207175, 1.236993, 7.047898)
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634  # Weight for Component 1

# Component 2: Burr(0.028161, 0.856898, 50.277542)
alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 0.602366  # Weight for Component 2

# Generate a sequence of x values to plot the density
x_vals <- seq(0.01, 10, by = 0.01)

# Calculate the weighted density of each component by multiplying the density by its weight
density1 <- pi1 * burr_pdf(x_vals, alpha1, theta1, gamma1)  # Weighted Component 1 density
density2 <- pi2 * burr_pdf(x_vals, alpha2, theta2, gamma2)  # Weighted Component 2 density

# Calculate the weighted density of each component by multiplying the density by its weight
cdf1 <- pi1 * burr_cdf(x_vals, alpha1, theta1, gamma1)  # Weighted Component 1 density
cdf2 <- pi2 * burr_cdf(x_vals, alpha2, theta2, gamma2)  # Weighted Component 2 density


# Mixture density function (weighted sum of the two component densities)
mixture_density <- density1 + density2  # Combine the weighted densities

# Mixture density function (weighted sum of the two component densities)
cdfmixture_density <- cdf1 + cdf2  # Combine the weighted densities

# Create a data frame for plotting
df <- data.frame(
  x = rep(x_vals, 3),  # Repeat x values for all three distributions
  y = c(density1, density2, mixture_density),  # Combine all y values for the densities
  Distribution = factor(rep(c("1-Component", "2-Component", "Mixture"), each = length(x_vals)))
  # Define the labels for each distribution in the plot
)

# Plot the density functions of the two components and the mixture
ggplot(df, aes(x = x, y = y, color = Distribution, linetype = Distribution)) + 
  geom_line(size = 1) +  # Plot each line with the specified size
  scale_color_manual(values = c("blue", "red", "black")) +  # Assign specific colors to components
  scale_linetype_manual(values = c("dashed", "dashed", "solid")) +  # Set linetypes: dashed for components, solid for mixture
  labs(x = "x", y = "Density") +  # Set plot title and axis labels
  theme_minimal() +  # Use a minimal theme for the plot
  theme(legend.title = element_blank())  # Remove legend title for a cleaner look

# Create a data frame for plotting
cdf <- data.frame(
  x = rep(x_vals, 3),  # Repeat x values for all three distributions
  y = c(cdf1, cdf2, cdfmixture_density),  # Combine all y values for the densities
  Distribution = factor(rep(c("1-Component", "2-Component", "Mixture"), each = length(x_vals)))
  # Define the labels for each distribution in the plot
)

# Plot the cumulative density functions of the two components and the mixture
ggplot(cdf, aes(x = x, y = y, color = Distribution, linetype = Distribution)) + 
  geom_line(size = 1) +  # Plot each line with the specified size
  scale_color_manual(values = c("blue", "red", "black")) +  # Assign specific colors to components
  scale_linetype_manual(values = c("dashed", "dashed", "solid")) +  # Set linetypes: dashed for components, solid for mixture
  labs(title = "CDF Plots of 1-Component, 2-Component and Mixture Burr", 
       x = "x", y = "Density") +  # Set plot title and axis labels
  theme_minimal() +  # Use a minimal theme for the plot
  theme(legend.title = element_blank())  # Remove legend title for a cleaner look


# Function to generate random samples from a Burr distribution
rburr <- function(n, alpha, theta, gamma) {
  u <- runif(n)  # Generate 'n' uniform random numbers
  theta * ((1 - u)^(-1 / alpha) - 1)^(1 / gamma)  # Inverse CDF for Burr distribution
}

# Function to generate random samples from a mixture of two Burr distributions
rburr_mixture <- function(n, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  # Generate 'n' uniform random numbers between 0 and 1 for component selection
  component <- runif(n)
  
  # Initialize a vector to store the samples
  samples <- numeric(n)
  
  # Select samples from Component 1 based on the mixture probability pi1
  samples[component < pi1] <- rburr(sum(component < pi1), alpha1, theta1, gamma1)
  
  # Select samples from Component 2 based on the mixture probability pi2
  samples[component >= pi1] <- rburr(sum(component >= pi1), alpha2, theta2, gamma2)
  
  return(samples)  # Return the mixture samples
}


# Set seed for reproducibility
set.seed(123)

# Generate 1000 samples from the mixture of two Burr distributions
n <- 1000
mixture_sample <- rburr_mixture(n, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2)

# Split the samples based on their original component to create individual component samples
# (this step is optional and used here to separate the two components for plotting)
component <- runif(n)
sample1 <- mixture_sample[component < pi1]
sample2 <- mixture_sample[component >= pi1]

# Create data frames for plotting
df1 <- data.frame(x = sample1, Distribution = "1-Component")
df2 <- data.frame(x = sample2, Distribution = "2-Component")
df_mixture <- data.frame(x = mixture_sample, Distribution = "Mixture")

# Combine the data frames
df_combined <- rbind(df1, df2, df_mixture)

# Plot histograms for the components and the mixture in a grid
p <- ggplot(df_combined, aes(x = x)) +
  geom_histogram(aes(y = ..density..), bins = 30, fill = "skyblue", color = "black", alpha = 0.7) +
  facet_grid(~ Distribution) + 
  labs(title = "Histograms for Burr Distribution Components and Mixture", x = "x", y = "Density") +
  theme_minimal()

# Display the grid of histograms
p


#' 
#' 
#' 
#' 
#' ## KS test statistic and p-value
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Correct Burr distribution cumulative distribution function (CDF)
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# CDF for the mixture of two Burr distributions
pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the 2-K Burr model from your professor's work
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634  # Weight for Component 1

alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 0.602366  # Weight for Component 2

# Perform the Kolmogorov-Smirnov test using the mixture CDF and the Danish dataset
ks_test_result <- ks.test(danish, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))

# Print the test statistic and p-value
print(ks_test_result)

#' 
#' ## Generating Random Burr Samples using rbinom
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Load necessary libraries
library(actuar)
library(ggplot2)
library(gridExtra)

# Burr CDF function for a single component
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# Mixture CDF for two Burr distributions
pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the Burr mixture model (null hypothesis)
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634
alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 1 - pi1

# Parameters for the alternative model (slightly modified)
alt_alpha1 <- 0.2
alt_theta1 <- 1.2
alt_gamma1 <- 7.1
alt_alpha2 <- 0.02
alt_theta2 <- 0.9
alt_gamma2 <- 50.4

# Function to generate samples from the Burr mixture model
generate_burr_mixture_samples <- function(n, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alpha1, theta1, gamma1),
                    rburr(n, alpha2, theta2, gamma2))
  return(samples)
}

# Function to generate samples under the alternative model
generate_alternative_samples <- function(n, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alt_alpha1, alt_theta1, alt_gamma1),
                    rburr(n, alt_alpha2, alt_theta2, alt_gamma2))
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_level <- 0.05

# Create lists to store plots
plots_null <- list()
plots_alt <- list()

# Loop through each sample size
for (sample_size in sample_sizes) {
  # Initialize vectors to store p-values
  p_values_null <- numeric(n_sims)
  p_values_alt <- numeric(n_sims)
  
  # Null hypothesis p-value simulations
  for (i in 1:n_sims) {
    samples_null <- generate_burr_mixture_samples(sample_size, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2)
    ks_test_null <- ks.test(samples_null, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
    p_values_null[i] <- ks_test_null$p.value
  }
  
  # Alternative hypothesis p-value simulations
  for (i in 1:n_sims) {
    samples_alt <- generate_alternative_samples(sample_size, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2)
    ks_test_alt <- ks.test(samples_alt, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
    p_values_alt[i] <- ks_test_alt$p.value
  }
  
  # Convert p-values to data frames for ggplot
  df_pvalues_null <- data.frame(p_value = p_values_null)
  df_pvalues_alt <- data.frame(p_value = p_values_alt)
  
# Create histogram for null hypothesis
p_null <- ggplot(df_pvalues_null, aes(x = p_value)) +
  geom_histogram(aes(y = after_stat(count) / sum(after_stat(count))), 
                 bins = 30, fill = "lightblue", color = "black", alpha = 0.7) +
  geom_vline(xintercept = alpha_level, color = "red", size = 1) +
  labs(subtitle = paste("n =", sample_size),
       x = "P-Value",
       y = "Proportion") +
  theme_minimal() +
theme(panel.grid = element_blank(),
      axis.title = element_blank())


# Create histogram for alternative hypothesis
p_alt <- ggplot(df_pvalues_alt, aes(x = p_value)) +
  geom_histogram(aes(y = after_stat(count) / sum(after_stat(count))), 
                 bins = 30, fill = "lightgreen", color = "black", alpha = 0.7) +
  geom_vline(xintercept = alpha_level, color = "red", size = 1) +
  labs(subtitle = paste("n =", sample_size),
       x = "P-Value",
       y = "Proportion") +
theme_minimal() +
theme(panel.grid = element_blank(),
      axis.title = element_blank())
  
  # Store the plots in lists
  plots_null[[as.character(sample_size)]] <- p_null
  plots_alt[[as.character(sample_size)]] <- p_alt
}


# For null plots
grid.arrange(
  arrangeGrob(grobs = plots_null, ncol = 2, nrow = 3),
  top = textGrob("KS", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)


# For alternative plots
grid.arrange(
  arrangeGrob(grobs = plots_alt, ncol = 2, nrow = 3),
  top = textGrob("KS", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)

#' 
#' 
#' ## Results for simulated randomly generated Burr samples using rbinom
#' ### Power and type 1 error rates for different values of alpha
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Load necessary library
library(actuar)

# Define the Burr CDF function
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# Mixture CDF for two Burr distributions
pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the Burr mixture model (null hypothesis)
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634  # Weight for Component 1

alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 1 - pi1  # Weight for Component 2

# Parameters for the alternative model (closer to the null model)
alt_alpha1 <- 0.2
alt_theta1 <- 1.2
alt_gamma1 <- 7.1
alt_alpha2 <- 0.02
alt_theta2 <- 0.9
alt_gamma2 <- 50.4

# Function to generate random samples from the Burr mixture model (null hypothesis)
generate_burr_mixture_samples <- function(n, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alpha1, theta1, gamma1),  # Component 1
                    rburr(n, alpha2, theta2, gamma2))   # Component 2
  return(samples)
}

# Function to generate samples under the alternative Burr mixture model
generate_alternative_samples <- function(n, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alt_alpha1, alt_theta1, alt_gamma1),  # Alternative Component 1
                    rburr(n, alt_alpha2, alt_theta2, alt_gamma2))   # Alternative Component 2
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 50, 100, 500, 1000, 2000, 2500)
n_sims <- 2000  # Number of simulations
alpha_values <- c(0.01, 0.05, 0.1)  # List of significance levels

# Loop through each alpha value and sample size
for (alpha in alpha_values) {
  
  # Initialize data frame to store results for current alpha
  results <- data.frame(Sample_Size = integer(), Type_I_Error_Rate = numeric(), Power = numeric())
  
  # Loop through each sample size
  for (sample_size in sample_sizes) {
    
    # Initialize counters
    type_I_errors <- 0
    power_count <- 0
    
    # Type I Error Simulation: Null model
    for (i in 1:n_sims) {
      samples_null <- generate_burr_mixture_samples(sample_size, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2)
      ks_test_null <- ks.test(samples_null, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
      if (ks_test_null$p.value < alpha) {
        type_I_errors <- type_I_errors + 1
      }
    }
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_alternative_samples(sample_size, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2)
      ks_test_alt <- ks.test(samples_alt, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
      if (ks_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Type I Error Rate and Power for current sample size
    type_I_error_rate <- type_I_errors / n_sims
    power <- power_count / n_sims
    
    # Store results in the data frame
    results <- rbind(results, data.frame(Sample_Size = sample_size, Type_I_Error_Rate = type_I_error_rate, Power = power))
  }
  
  # Print results for the current alpha value
  cat("\nResults for alpha =", alpha, "\n")
  print(results)
}

#' 
#' # Power curve for the different alpha values
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Define the Burr CDF function and mixture CDF for two Burr distributions
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the null and alternative Burr mixture models
alpha1 <- 0.207175; theta1 <- 1.236993; gamma1 <- 7.047898; pi1 <- 0.397634
alpha2 <- 0.028161; theta2 <- 0.856898; gamma2 <- 50.277542; pi2 <- 1 - pi1

alt_alpha1 <- 0.2; alt_theta1 <- 1.2; alt_gamma1 <- 7.1
alt_alpha2 <- 0.02; alt_theta2 <- 0.9; alt_gamma2 <- 50.4

# Function to generate samples from the null and alternative models
generate_burr_mixture_samples <- function(n, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  ifelse(component == 1, rburr(n, alpha1, theta1, gamma1), rburr(n, alpha2, theta2, gamma2))
}

generate_alternative_samples <- function(n, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  ifelse(component == 1, rburr(n, alt_alpha1, alt_theta1, alt_gamma1), rburr(n, alt_alpha2, alt_theta2, alt_gamma2))
}

# Simulation settings
n_sims <- 2000  # Number of simulations
alpha_values <- c(0.01, 0.05, 0.1)  # Significance levels
step_size <- 10  # Increment in sample size

# Initialize a list to store power curve data for each alpha
power_curves <- list()

# Loop through each alpha value to compute the power curve
for (alpha in alpha_values) {
  
  # Initialize starting sample size, power, and vectors to store sample sizes and power values
  sample_size <- 10
  power <- 0
  sample_sizes <- c()
  power_values <- c()
  
  # Increment sample size until power reaches 1
  while (power < 1) {
    power_count <- 0
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_alternative_samples(sample_size, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2)
      ks_test_alt <- ks.test(samples_alt, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
      if (ks_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Power for the current sample size
    power <- power_count / n_sims
    
    # Store the sample size and power values
    sample_sizes <- c(sample_sizes, sample_size)
    power_values <- c(power_values, power)
    
    # Increment sample size if power is less than 1
    if (power < 1) {
      sample_size <- sample_size + step_size
    }
  }
  
  # Store the results for the current alpha value in the list
  power_curves[[paste0("alpha_", alpha)]] <- data.frame(Sample_Size = sample_sizes, Power = power_values)
  
  # Print the minimum sample size where power reaches 1
  min_sample_size_power_1 <- sample_size
  cat("\nMinimum sample size where power reaches 1 for alpha =", alpha, ":", min_sample_size_power_1, "\n")
}

# Plot the Power curves for each alpha
colors <- c("blue", "purple", "green")
plot(NULL, xlim=c(10, max(unlist(lapply(power_curves, function(df) df$Sample_Size)))), 
     ylim=c(0, 1), xlab="Sample Size", ylab="Power")

for (i in seq_along(alpha_values)) {
  alpha <- alpha_values[i]
  power_data <- power_curves[[paste0("alpha_", alpha)]]
  lines(power_data$Sample_Size, power_data$Power, col=colors[i], type="l", lwd=2)
  abline(h=1, col="red", lty=2)  # Reference line for Power = 1
}

legend("bottomright", legend=paste("Alpha =", alpha_values), col=colors, lwd=2)

power_curves_KS <- power_curves

#' 
#' 
#' # AD test statistic and p-value
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Correct Burr distribution CDF function
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# CDF for the mixture of two Burr distributions
pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the 2-K Burr model from your professor's work
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634  # Weight for Component 1

alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 0.602366  # Weight for Component 2

# Perform the Anderson-Darling test using the mixture CDF and the Danish dataset
ad_test_result <- ADGofTest::ad.test(danish, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))

# Print the test statistic and p-value
print(ad_test_result)



#' 
#' 
#' # Using rbinom for sampling distribution of p-values for different sample sizes
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Load necessary libraries
library(actuar)
library(ggplot2)
library(gridExtra)

# Burr CDF function for a single component
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# Mixture CDF for two Burr distributions
pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the Burr mixture model (null hypothesis)
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634
alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 1 - pi1

# Parameters for the alternative model (slightly modified)
alt_alpha1 <- 0.2
alt_theta1 <- 1.2
alt_gamma1 <- 7.1
alt_alpha2 <- 0.02
alt_theta2 <- 0.9
alt_gamma2 <- 50.4

# Function to generate samples from the Burr mixture model
generate_burr_mixture_samples <- function(n, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alpha1, theta1, gamma1),
                    rburr(n, alpha2, theta2, gamma2))
  return(samples)
}

# Function to generate samples under the alternative model
generate_alternative_samples <- function(n, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alt_alpha1, alt_theta1, alt_gamma1),
                    rburr(n, alt_alpha2, alt_theta2, alt_gamma2))
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_level <- 0.05

# Create lists to store plots
plots_null <- list()
plots_alt <- list()

# Loop through each sample size
for (sample_size in sample_sizes) {
  # Initialize vectors to store p-values
  p_values_null <- numeric(n_sims)
  p_values_alt <- numeric(n_sims)
  
  # Null hypothesis p-value simulations
  for (i in 1:n_sims) {
    samples_null <- generate_burr_mixture_samples(sample_size, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2)
    ad_test_null <- ADGofTest::ad.test(samples_null, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
    p_values_null[i] <- ad_test_null$p.value
  }
  
  # Alternative hypothesis p-value simulations
  for (i in 1:n_sims) {
    samples_alt <- generate_alternative_samples(sample_size, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2)
    ad_test_alt <- ADGofTest::ad.test(samples_alt, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
    p_values_alt[i] <- ad_test_alt$p.value
  }
  
  # Convert p-values to data frames for ggplot
  df_pvalues_null <- data.frame(p_value = p_values_null)
  df_pvalues_alt <- data.frame(p_value = p_values_alt)
  
# Create histogram for null hypothesis
p_null <- ggplot(df_pvalues_null, aes(x = p_value)) +
  geom_histogram(aes(y = after_stat(count) / sum(after_stat(count))), 
                 bins = 30, fill = "lightblue", color = "black", alpha = 0.7) +
  geom_vline(xintercept = alpha_level, color = "red", size = 1) +
  labs(subtitle = paste("n =", sample_size),
       x = "P-Value",
       y = "Proportion") +
  theme_minimal() +
theme(panel.grid = element_blank(),
      axis.title = element_blank())


# Create histogram for alternative hypothesis
p_alt <- ggplot(df_pvalues_alt, aes(x = p_value)) +
  geom_histogram(aes(y = after_stat(count) / sum(after_stat(count))), 
                 bins = 30, fill = "lightgreen", color = "black", alpha = 0.7) +
  geom_vline(xintercept = alpha_level, color = "red", size = 1) +
  labs(subtitle = paste("n =", sample_size),
       x = "P-Value",
       y = "Proportion") +
theme_minimal() +
theme(panel.grid = element_blank(),
      axis.title = element_blank())
  
  # Store the plots in lists
  plots_null[[as.character(sample_size)]] <- p_null
  plots_alt[[as.character(sample_size)]] <- p_alt
}

# For null plots
grid.arrange(
  arrangeGrob(grobs = plots_null, ncol = 2, nrow = 3),
  top = textGrob("AD", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)


# For alternative plots
grid.arrange(
  arrangeGrob(grobs = plots_alt, ncol = 2, nrow = 3),
  top = textGrob("AD", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)

#' 
#' # Results for randomly generated Burr samples 
#' ## Power and type 1 error rates for different values of alpha
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Load necessary library
library(actuar)

# Define the Burr CDF function
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# Mixture CDF for two Burr distributions
pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the Burr mixture model (null hypothesis)
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634  # Weight for Component 1

alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 1 - pi1  # Weight for Component 2

# Parameters for the alternative model (closer to the null model)
alt_alpha1 <- 0.2
alt_theta1 <- 1.2
alt_gamma1 <- 7.1
alt_alpha2 <- 0.02
alt_theta2 <- 0.9
alt_gamma2 <- 50.4

# Function to generate random samples from the Burr mixture model (null hypothesis)
generate_burr_mixture_samples <- function(n, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alpha1, theta1, gamma1),  # Component 1
                    rburr(n, alpha2, theta2, gamma2))   # Component 2
  return(samples)
}

# Function to generate samples under the alternative Burr mixture model
generate_alternative_samples <- function(n, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alt_alpha1, alt_theta1, alt_gamma1),  # Alternative Component 1
                    rburr(n, alt_alpha2, alt_theta2, alt_gamma2))   # Alternative Component 2
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 50, 100, 500, 1000, 2000, 2500)
n_sims <- 2000  # Number of simulations
alpha_values <- c(0.01, 0.05, 0.1)  # List of significance levels

# Loop through each alpha value and sample size
for (alpha in alpha_values) {
  
  # Initialize data frame to store results for current alpha
  results <- data.frame(Sample_Size = integer(), Type_I_Error_Rate = numeric(), Power = numeric())
  
  # Loop through each sample size
  for (sample_size in sample_sizes) {
    
    # Initialize counters
    type_I_errors <- 0
    power_count <- 0
    
    # Type I Error Simulation: Null model
    for (i in 1:n_sims) {
      samples_null <- generate_burr_mixture_samples(sample_size, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2)
      ad_test_null <- ADGofTest::ad.test(samples_null, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
      if (ad_test_null$p.value < alpha) {
        type_I_errors <- type_I_errors + 1
      }
    }
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_alternative_samples(sample_size, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2)
      ad_test_alt <- ADGofTest::ad.test(samples_alt, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
      if (ad_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Type I Error Rate and Power for current sample size
    type_I_error_rate <- type_I_errors / n_sims
    power <- power_count / n_sims
    
    # Store results in the data frame
    results <- rbind(results, data.frame(Sample_Size = sample_size, Type_I_Error_Rate = type_I_error_rate, Power = power))
  }
  
  # Print results for the current alpha value
  cat("\nResults for alpha =", alpha, "\n")
  print(results)
}

#' 
#' # Power curve for the different alpha values
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Define the Burr CDF function and mixture CDF for two Burr distributions
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the null and alternative Burr mixture models
alpha1 <- 0.207175; theta1 <- 1.236993; gamma1 <- 7.047898; pi1 <- 0.397634
alpha2 <- 0.028161; theta2 <- 0.856898; gamma2 <- 50.277542; pi2 <- 1 - pi1

alt_alpha1 <- 0.2; alt_theta1 <- 1.2; alt_gamma1 <- 7.1
alt_alpha2 <- 0.02; alt_theta2 <- 0.9; alt_gamma2 <- 50.4

# Function to generate samples from the null and alternative models
generate_burr_mixture_samples <- function(n, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  ifelse(component == 1, rburr(n, alpha1, theta1, gamma1), rburr(n, alpha2, theta2, gamma2))
}

generate_alternative_samples <- function(n, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  ifelse(component == 1, rburr(n, alt_alpha1, alt_theta1, alt_gamma1), rburr(n, alt_alpha2, alt_theta2, alt_gamma2))
}

# Simulation settings
n_sims <- 2000  # Number of simulations
alpha_values <- c(0.01, 0.05, 0.1)  # Significance levels
step_size <- 10  # Increment in sample size

# Initialize a list to store power curve data for each alpha
power_curves <- list()

# Loop through each alpha value to compute the power curve
for (alpha in alpha_values) {
  
  # Initialize starting sample size, power, and vectors to store sample sizes and power values
  sample_size <- 10
  power <- 0
  sample_sizes <- c()
  power_values <- c()
  
  # Increment sample size until power reaches 1
  while (power < 1) {
    power_count <- 0
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_alternative_samples(sample_size, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2)
      ad_test_alt <- ADGofTest::ad.test(samples_alt, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
      if (ad_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Power for the current sample size
    power <- power_count / n_sims
    
    # Store the sample size and power values
    sample_sizes <- c(sample_sizes, sample_size)
    power_values <- c(power_values, power)
    
    # Increment sample size if power is less than 1
    if (power < 1) {
      sample_size <- sample_size + step_size
    }
  }
  
  # Store the results for the current alpha value in the list
  power_curves[[paste0("alpha_", alpha)]] <- data.frame(Sample_Size = sample_sizes, Power = power_values)
  
  # Print the minimum sample size where power reaches 1
  min_sample_size_power_1 <- sample_size
  cat("\nMinimum sample size where power reaches 1 for alpha =", alpha, ":", min_sample_size_power_1, "\n")
}

# Plot the Power curves for each alpha
colors <- c("blue", "purple", "green")
plot(NULL, xlim=c(10, max(unlist(lapply(power_curves, function(df) df$Sample_Size)))), 
     ylim=c(0, 1), xlab="Sample Size", ylab="Power")

for (i in seq_along(alpha_values)) {
  alpha <- alpha_values[i]
  power_data <- power_curves[[paste0("alpha_", alpha)]]
  lines(power_data$Sample_Size, power_data$Power, col=colors[i], type="l", lwd=2)
  abline(h=1, col="red", lty=2)  # Reference line for Power = 1
}

legend("bottomright", legend=paste("Alpha =", alpha_values), col=colors, lwd=2)

power_curves_AD <- power_curves  # Save AD results

#' 
#' # Cramervon Mises 
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Load necessary package for CvM test if needed
# install.packages("goftest")  # Uncomment to install if not installed
# library(goftest)

# Correct Burr distribution CDF function
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# CDF for the mixture of two Burr distributions
pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the 2-K Burr model from your professor's work
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634  # Weight for Component 1

alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 0.602366  # Weight for Component 2

# Perform the Cramér-von Mises test using the mixture CDF and the Danish dataset
cvm_test_result <- goftest::cvm.test(danish, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))

# Print the test statistic and p-value
print(cvm_test_result)

#' 
## ----warning=FALSE, echo=TRUE----------------------------------------------------------

# Load necessary libraries
library(actuar)
library(ggplot2)
library(gridExtra)

# Burr CDF function for a single component
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# Mixture CDF for two Burr distributions
pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the Burr mixture model (null hypothesis)
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634
alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 1 - pi1

# Parameters for the alternative model (slightly modified)
alt_alpha1 <- 0.2
alt_theta1 <- 1.2
alt_gamma1 <- 7.1
alt_alpha2 <- 0.02
alt_theta2 <- 0.9
alt_gamma2 <- 50.4

# Function to generate samples from the Burr mixture model
generate_burr_mixture_samples <- function(n, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alpha1, theta1, gamma1),
                    rburr(n, alpha2, theta2, gamma2))
  return(samples)
}

# Function to generate samples under the alternative model
generate_alternative_samples <- function(n, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alt_alpha1, alt_theta1, alt_gamma1),
                    rburr(n, alt_alpha2, alt_theta2, alt_gamma2))
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_level <- 0.05

# Create lists to store plots
plots_null <- list()
plots_alt <- list()

# Loop through each sample size
for (sample_size in sample_sizes) {
  # Initialize vectors to store p-values
  p_values_null <- numeric(n_sims)
  p_values_alt <- numeric(n_sims)
  
  # Null hypothesis p-value simulations
  for (i in 1:n_sims) {
    samples_null <- generate_burr_mixture_samples(sample_size, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2)
    cvm_test_null <- goftest::cvm.test(samples_null, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
    p_values_null[i] <- cvm_test_null$p.value
  }
  
  # Alternative hypothesis p-value simulations
  for (i in 1:n_sims) {
    samples_alt <- generate_alternative_samples(sample_size, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2)
    cvm_test_alt <- goftest::cvm.test(samples_alt, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
    p_values_alt[i] <- cvm_test_alt$p.value
  }
  
  # Convert p-values to data frames for ggplot
  df_pvalues_null <- data.frame(p_value = p_values_null)
  df_pvalues_alt <- data.frame(p_value = p_values_alt)
  
# Create histogram for null hypothesis
p_null <- ggplot(df_pvalues_null, aes(x = p_value)) +
  geom_histogram(aes(y = after_stat(count) / sum(after_stat(count))), 
                 bins = 30, fill = "lightblue", color = "black", alpha = 0.7) +
  geom_vline(xintercept = alpha_level, color = "red", size = 1) +
  labs(subtitle = paste("n =", sample_size),
       x = "P-Value",
       y = "Proportion") +
  theme_minimal() +
theme(panel.grid = element_blank(),
      axis.title = element_blank())


# Create histogram for alternative hypothesis
p_alt <- ggplot(df_pvalues_alt, aes(x = p_value)) +
  geom_histogram(aes(y = after_stat(count) / sum(after_stat(count))), 
                 bins = 30, fill = "lightgreen", color = "black", alpha = 0.7) +
  geom_vline(xintercept = alpha_level, color = "red", size = 1) +
  labs(subtitle = paste("n =", sample_size),
       x = "P-Value",
       y = "Proportion") +
theme_minimal() +
theme(panel.grid = element_blank(),
      axis.title = element_blank())
  
  # Store the plots in lists
  plots_null[[as.character(sample_size)]] <- p_null
  plots_alt[[as.character(sample_size)]] <- p_alt
}

# For null plots
grid.arrange(
  arrangeGrob(grobs = plots_null, ncol = 2, nrow = 3),
  top = textGrob("CvM", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)


# For alternative plots
grid.arrange(
  arrangeGrob(grobs = plots_alt, ncol = 2, nrow = 3),
  top = textGrob("CvM", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)

#' 
#' ## Results for randomly generated Burr samples 
#' ## Power and type 1 error rates for different values of alpha
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Load necessary library
library(actuar)

# Define the Burr CDF function
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# Mixture CDF for two Burr distributions
pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the Burr mixture model (null hypothesis)
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634  # Weight for Component 1

alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 1 - pi1  # Weight for Component 2

# Parameters for the alternative model (closer to the null model)
alt_alpha1 <- 0.2
alt_theta1 <- 1.2
alt_gamma1 <- 7.1
alt_alpha2 <- 0.02
alt_theta2 <- 0.9
alt_gamma2 <- 50.4

# Function to generate random samples from the Burr mixture model (null hypothesis)
generate_burr_mixture_samples <- function(n, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alpha1, theta1, gamma1),  # Component 1
                    rburr(n, alpha2, theta2, gamma2))   # Component 2
  return(samples)
}

# Function to generate samples under the alternative Burr mixture model
generate_alternative_samples <- function(n, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alt_alpha1, alt_theta1, alt_gamma1),  # Alternative Component 1
                    rburr(n, alt_alpha2, alt_theta2, alt_gamma2))   # Alternative Component 2
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 50, 100, 500, 1000, 2000, 2500)
n_sims <- 2000  # Number of simulations
alpha_values <- c(0.01, 0.05, 0.1)  # List of significance levels

# Loop through each alpha value and sample size
for (alpha in alpha_values) {
  
  # Initialize data frame to store results for current alpha
  results <- data.frame(Sample_Size = integer(), Type_I_Error_Rate = numeric(), Power = numeric())
  
  # Loop through each sample size
  for (sample_size in sample_sizes) {
    
    # Initialize counters
    type_I_errors <- 0
    power_count <- 0
    
    # Type I Error Simulation: Null model
    for (i in 1:n_sims) {
      samples_null <- generate_burr_mixture_samples(sample_size, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2)
      cvm_test_null <- goftest::cvm.test(samples_null, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
      if (cvm_test_null$p.value < alpha) {
        type_I_errors <- type_I_errors + 1
      }
    }
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_alternative_samples(sample_size, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2)
      cvm_test_alt <- goftest::cvm.test(samples_alt, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
      if (cvm_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Type I Error Rate and Power for current sample size
    type_I_error_rate <- type_I_errors / n_sims
    power <- power_count / n_sims
    
    # Store results in the data frame
    results <- rbind(results, data.frame(Sample_Size = sample_size, Type_I_Error_Rate = type_I_error_rate, Power = power))
  }
  
  # Print results for the current alpha value
  cat("\nResults for alpha =", alpha, "\n")
  print(results)
}

#' 
#' # Power curve for the different alpha values
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Define the Burr CDF function and mixture CDF for two Burr distributions
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the null and alternative Burr mixture models
alpha1 <- 0.207175; theta1 <- 1.236993; gamma1 <- 7.047898; pi1 <- 0.397634
alpha2 <- 0.028161; theta2 <- 0.856898; gamma2 <- 50.277542; pi2 <- 1 - pi1

alt_alpha1 <- 0.2; alt_theta1 <- 1.2; alt_gamma1 <- 7.1
alt_alpha2 <- 0.02; alt_theta2 <- 0.9; alt_gamma2 <- 50.4

# Function to generate samples from the null and alternative models
generate_burr_mixture_samples <- function(n, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  ifelse(component == 1, rburr(n, alpha1, theta1, gamma1), rburr(n, alpha2, theta2, gamma2))
}

generate_alternative_samples <- function(n, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  ifelse(component == 1, rburr(n, alt_alpha1, alt_theta1, alt_gamma1), rburr(n, alt_alpha2, alt_theta2, alt_gamma2))
}

# Simulation settings
n_sims <- 2000  # Number of simulations
alpha_values <- c(0.01, 0.05, 0.1)  # Significance levels
step_size <- 10  # Increment in sample size

# Initialize a list to store power curve data for each alpha
power_curves <- list()

# Loop through each alpha value to compute the power curve
for (alpha in alpha_values) {
  
  # Initialize starting sample size, power, and vectors to store sample sizes and power values
  sample_size <- 10
  power <- 0
  sample_sizes <- c()
  power_values <- c()
  
  # Increment sample size until power reaches 1
  while (power < 1) {
    power_count <- 0
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_alternative_samples(sample_size, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2)
      cvm_test_alt <- goftest::cvm.test(samples_alt, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
      if (cvm_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Power for the current sample size
    power <- power_count / n_sims
    
    # Store the sample size and power values
    sample_sizes <- c(sample_sizes, sample_size)
    power_values <- c(power_values, power)
    
    # Increment sample size if power is less than 1
    if (power < 1) {
      sample_size <- sample_size + step_size
    }
  }
  
  # Store the results for the current alpha value in the list
  power_curves[[paste0("alpha_", alpha)]] <- data.frame(Sample_Size = sample_sizes, Power = power_values)
  
  # Print the minimum sample size where power reaches 1
  min_sample_size_power_1 <- sample_size
  cat("\nMinimum sample size where power reaches 1 for alpha =", alpha, ":", min_sample_size_power_1, "\n")
}

# Plot the Power curves for each alpha
colors <- c("blue", "purple", "green")
plot(NULL, xlim=c(10, max(unlist(lapply(power_curves, function(df) df$Sample_Size)))), 
     ylim=c(0, 1), xlab="Sample Size", ylab="Power")

for (i in seq_along(alpha_values)) {
  alpha <- alpha_values[i]
  power_data <- power_curves[[paste0("alpha_", alpha)]]
  lines(power_data$Sample_Size, power_data$Power, col=colors[i], type="l", lwd=2)
  abline(h=1, col="red", lty=2)  # Reference line for Power = 1
}

legend("bottomright", legend=paste("Alpha =", alpha_values), col=colors, lwd=2)

power_curves_CvM <- power_curves

#' 
#' 
#' 
#' 
#' # CHI-SQUARED
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Load necessary libraries
library(actuar)
library(ggplot2)
library(gridExtra)
library(SMPracticals)

data(danish)
data <- danish

# Dynamic Equal-Frequency Binning Function
dynamic_binning <- function(data) {
  # Determine the number of bins dynamically using Sturges' formula
  num_bins <- max(10, floor(1 + log2(length(data))))  # At least 10 bins
  bin_edges <- quantile(data, probs = seq(0, 1, length.out = num_bins + 1))
  
  # Calculate observed frequencies
  observed <- hist(data, breaks = bin_edges, plot = FALSE)$counts
  
  return(list(observed = observed, bin_edges = bin_edges))
}

# Chi-Square Test with Dynamic Binning
chi_square_test_dynamic <- function(data, cdf_func, params) {
  # Get dynamically determined bins
  bins <- dynamic_binning(data)
  
  # Extract parameters from the list
  alpha1 <- params$alpha1
  theta1 <- params$theta1
  gamma1 <- params$gamma1
  alpha2 <- params$alpha2
  theta2 <- params$theta2
  gamma2 <- params$gamma2
  pi1 <- params$pi1
  pi2 <- 1 - pi1  # Calculate pi2 from pi1
  
  # Calculate expected frequencies
  expected <- sapply(1:(length(bins$bin_edges) - 1), function(i) {
    p1 <- cdf_func(bins$bin_edges[i], alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2)
    p2 <- cdf_func(bins$bin_edges[i + 1], alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2)
    length(data) * (p2 - p1)
  })
  
  # Safeguard: Check minimum expected count
  if (any(expected < 5)) {
    warning("Some bins have expected counts < 5. Consider further adjustments.")
  }
  
  # Perform Chi-Square test
  return(chisq.test(bins$observed, p = expected / sum(expected), rescale.p = TRUE))
}

# Burr CDF function for a single component
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# Mixture CDF for two Burr distributions
pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the Burr mixture model (null hypothesis)
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634
alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 1 - pi1

params_null <- list(alpha1 = alpha1, theta1 = theta1, gamma1 = gamma1,
                    alpha2 = alpha2, theta2 = theta2, gamma2 = gamma2, pi1 = pi1)

# Parameters for the alternative hypothesis
alt_alpha1 <- 0.2
alt_theta1 <- 1.2
alt_gamma1 <- 7.1
alt_alpha2 <- 0.02
alt_theta2 <- 0.9
alt_gamma2 <- 50.4

params_alt <- list(alpha1 = alt_alpha1, theta1 = alt_theta1, gamma1 = alt_gamma1,
                   alpha2 = alt_alpha2, theta2 = alt_theta2, gamma2 = alt_gamma2, pi1 = pi1)

# Function to generate samples under the Burr mixture model
generate_burr_mixture_samples <- function(n, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alpha1, theta1, gamma1),
                    rburr(n, alpha2, theta2, gamma2))
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_level <- 0.05

# Initialize lists to store results
p_values_null <- list()
p_values_alt <- list()

# Simulation loop
for (sample_size in sample_sizes) {
  p_values_null[[as.character(sample_size)]] <- numeric(n_sims)
  p_values_alt[[as.character(sample_size)]] <- numeric(n_sims)
  
  for (i in 1:n_sims) {
    # Generate null hypothesis samples
    samples_null <- generate_burr_mixture_samples(sample_size, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2)
    chi_sq_null <- chi_square_test_dynamic(samples_null, pburr_mixture, params_null)
    p_values_null[[as.character(sample_size)]][i] <- chi_sq_null$p.value
    
    # Generate alternative hypothesis samples
    samples_alt <- generate_burr_mixture_samples(sample_size, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2)
    chi_sq_alt <- chi_square_test_dynamic(samples_alt, pburr_mixture, params_null)  # Null params for alt test
    p_values_alt[[as.character(sample_size)]][i] <- chi_sq_alt$p.value
  }
}

plot_p_values <- function(p_values, sample_sizes, hypothesis, color) {
  plots <- list()
  for (sample_size in sample_sizes) {
    p_data <- data.frame(p_value = p_values[[as.character(sample_size)]])
    plot <- ggplot(p_data, aes(x = p_value)) +
      geom_histogram(aes(y = after_stat(count / sum(count))), 
                     bins = 30, fill = color, color = "black", alpha = 0.7) +
      geom_vline(xintercept = alpha_level, color = "red", size = 1) +
      labs(subtitle = paste("n =", sample_size)) +
      scale_x_continuous(limits = c(0, 1)) +
      theme_minimal() +
      theme(
        panel.grid = element_blank(),
        axis.title = element_blank()
      )
    plots[[as.character(sample_size)]] <- plot
  }
  return(plots)
}

# Generate histograms for null and alternative hypotheses with different colors
plots_null <- plot_p_values(p_values_null, sample_sizes, "Null Hypothesis", color = "lightblue")
plots_alt <- plot_p_values(p_values_alt, sample_sizes, "Alternative Hypothesis", color = "lightgreen")


# For null plots
grid.arrange(
  arrangeGrob(grobs = plots_null, ncol = 2, nrow = 3),
  top = textGrob("CHI-SQUARE", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)


# For alternative plots
grid.arrange(
  arrangeGrob(grobs = plots_alt, ncol = 2, nrow = 3),
  top = textGrob("CHI-SQUARE", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)


# Revised Chi-Square Simulation with Fixes

# Load necessary libraries
library(actuar)
library(ggplot2)

# Equal Frequency Binning Function
equal_frequency_binning <- function(data, num_bins) {
  bin_edges <- quantile(data, probs = seq(0, 1, length.out = num_bins + 1))
  observed <- hist(data, breaks = bin_edges, plot = FALSE)$counts
  return(list(observed = observed, bin_edges = bin_edges))
}

# Chi-Square Test with Equal-Frequency Binning
chi_square_test_equal_freq <- function(data, cdf_func, params, num_bins) {
  bins <- equal_frequency_binning(data, num_bins)
  
  alpha1 <- params$alpha1
  theta1 <- params$theta1
  gamma1 <- params$gamma1
  alpha2 <- params$alpha2
  theta2 <- params$theta2
  gamma2 <- params$gamma2
  pi1 <- params$pi1
  pi2 <- 1 - pi1
  
  expected <- sapply(1:(length(bins$bin_edges) - 1), function(i) {
    p1 <- cdf_func(bins$bin_edges[i], alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2)
    p2 <- cdf_func(bins$bin_edges[i + 1], alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2)
    length(data) * (p2 - p1)
  })
  
  # Safeguard for small expected frequencies
  if (any(expected < 5)) {
    warning("Some bins have expected counts < 5. Consider reducing the number of bins.")
  }
  
  chisq.test(bins$observed, p = expected / sum(expected), rescale.p = TRUE)
}

# Parameters for Null and Alternative Hypotheses
params_null <- list(alpha1 = 0.207175, theta1 = 1.236993, gamma1 = 7.047898,
                    alpha2 = 0.028161, theta2 = 0.856898, gamma2 = 50.277542,
                    pi1 = 0.397634)

alt_params <- list(alpha1 = 0.2, theta1 = 1.2, gamma1 = 7.1,
                   alpha2 = 0.02, theta2 = 0.9, gamma2 = 50.4,
                   pi1 = 0.397634)

# Function to Generate Burr Samples
generate_burr_samples <- function(n, params) {
  component <- rbinom(n, 1, params$pi1)
  ifelse(component == 1,
         rburr(n, params$alpha1, params$theta1, params$gamma1),
         rburr(n, params$alpha2, params$theta2, params$gamma2))
}

# Simulation Settings
sample_sizes <- c(10, 50, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_values <- c(0.01, 0.05, 0.1)

# Loop Over Each Alpha Value
results_list <- list()

for (alpha in alpha_values) {
  
  # Initialize Results Data Frame
  results <- data.frame(Sample_Size = integer(), Type_I_Error_Rate = numeric(), Power = numeric())
  
  # Loop Over Each Sample Size
  for (sample_size in sample_sizes) {
    
    # Adjust number of bins dynamically
    num_bins <- max(10, floor(1 + log2(sample_size)))
    
    # Initialize Counters
    type_I_errors <- 0
    power_count <- 0
    
    # Type I Error Simulation (Null Hypothesis)
    for (i in 1:n_sims) {
      samples_null <- generate_burr_samples(sample_size, params_null)
      chi_sq_null <- chi_square_test_equal_freq(samples_null, pburr_mixture, params_null, num_bins)
      if (chi_sq_null$p.value < alpha) {
        type_I_errors <- type_I_errors + 1
      }
    }
    
    # Power Simulation (Alternative Hypothesis)
    for (i in 1:n_sims) {
      samples_alt <- generate_burr_samples(sample_size, alt_params)
      chi_sq_alt <- chi_square_test_equal_freq(samples_alt, pburr_mixture, params_null, num_bins)  # Null params for alt test
      if (chi_sq_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Type I Error Rate and Power
    type_I_error_rate <- type_I_errors / n_sims
    power <- power_count / n_sims
    
    # Store Results
    results <- rbind(results, data.frame(Sample_Size = sample_size, Type_I_Error_Rate = type_I_error_rate, Power = power))
  }
  
  # Store Results for Each Alpha
  results_list[[paste0("Alpha_", alpha)]] <- results
  cat("\nResults for alpha =", alpha, "\n")
  print(results)
}






# Load necessary libraries
library(actuar)

# Dynamic Equal-Frequency Binning Function
dynamic_binning <- function(data) {
  # Determine the number of bins dynamically using Sturges' formula
  num_bins <- max(10, floor(1 + log2(length(data))))  # At least 10 bins
  bin_edges <- quantile(data, probs = seq(0, 1, length.out = num_bins + 1))
  
  # Calculate observed frequencies
  observed <- hist(data, breaks = bin_edges, plot = FALSE)$counts
  return(list(observed = observed, bin_edges = bin_edges))
}

# Chi-Square Test with Dynamic Binning
chi_square_test_dynamic <- function(data, cdf_func, params) {
  bins <- dynamic_binning(data)
  
  alpha1 <- params$alpha1
  theta1 <- params$theta1
  gamma1 <- params$gamma1
  alpha2 <- params$alpha2
  theta2 <- params$theta2
  gamma2 <- params$gamma2
  pi1 <- params$pi1
  pi2 <- 1 - pi1
  
  expected <- sapply(1:(length(bins$bin_edges) - 1), function(i) {
    p1 <- cdf_func(bins$bin_edges[i], alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2)
    p2 <- cdf_func(bins$bin_edges[i + 1], alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2)
    length(data) * (p2 - p1)
  })
  
  chisq.test(bins$observed, p = expected / sum(expected), rescale.p = TRUE)
}

# Parameters for the null and alternative Burr mixture models
params_null <- list(alpha1 = 0.207175, theta1 = 1.236993, gamma1 = 7.047898,
                    alpha2 = 0.028161, theta2 = 0.856898, gamma2 = 50.277542, pi1 = 0.397634)

alt_params <- list(alpha1 = 0.2, theta1 = 1.2, gamma1 = 7.1,
                   alpha2 = 0.02, theta2 = 0.9, gamma2 = 50.4, pi1 = 0.397634)

# Function to generate Burr mixture samples
generate_burr_samples <- function(n, params) {
  component <- rbinom(n, 1, params$pi1)
  ifelse(component == 1,
         rburr(n, params$alpha1, params$theta1, params$gamma1),
         rburr(n, params$alpha2, params$theta2, params$gamma2))
}

# Simulation settings
n_sims <- 2000  # Number of simulations
alpha_values <- c(0.01, 0.05, 0.1)  # Significance levels
step_size <- 10  # Increment in sample size

# Initialize a list to store power curve data for each alpha
power_curves <- list()

# Loop through each alpha value to compute the power curve
for (alpha in alpha_values) {
  
  # Initialize starting sample size, power, and vectors to store sample sizes and power values
  sample_size <- 10
  power <- 0
  sample_sizes <- c()
  power_values <- c()
  
  # Increment sample size until power reaches 1
  while (power < 1) {
    power_count <- 0
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_burr_samples(sample_size, alt_params)
      chi_sq_alt <- chi_square_test_dynamic(samples_alt, pburr_mixture, params_null)  # Using dynamic binning
      if (chi_sq_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Power for the current sample size
    power <- power_count / n_sims
    
    # Store the sample size and power values
    sample_sizes <- c(sample_sizes, sample_size)
    power_values <- c(power_values, power)
    
    # Increment sample size if power is less than 1
    if (power < 1) {
      sample_size <- sample_size + step_size
    }
  }
  
  # Store the results for the current alpha value in the list
  power_curves[[paste0("alpha_", alpha)]] <- data.frame(Sample_Size = sample_sizes, Power = power_values)
  
  # Print the minimum sample size where power reaches 1
  min_sample_size_power_1 <- sample_size
  cat("\nMinimum sample size where power reaches 1 for alpha =", alpha, ":", min_sample_size_power_1, "\n")
}

# Plot the Power Curves for Each Alpha
colors <- c("blue", "purple", "green")
plot(NULL, xlim = c(10, max(unlist(lapply(power_curves, function(df) df$Sample_Size)))), 
     ylim = c(0, 1), xlab = "Sample Size", ylab = "Power")

for (i in seq_along(alpha_values)) {
  alpha <- alpha_values[i]
  power_data <- power_curves[[paste0("alpha_", alpha)]]
  lines(power_data$Sample_Size, power_data$Power, col = colors[i], type = "l", lwd = 2)
  abline(h = 1, col = "red", lty = 2)  # Reference line for Power = 1
}

legend("bottomright", legend = paste("Alpha =", alpha_values), col = colors, lwd = 2)

power_curves_Chisq <- power_curves

#' 
#' 
#' 
#' 
#' ### All at different alpha-level
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Colorblind-friendly colors and markers
test_names <- c("AD", "KS", "CvM", "Chi-Square")
test_colors <- c("#D55E00", "#0072B2", "#009E73", "#CC79A7")
test_pch <- c(16, 17, 15, 18)

# Explicit mapping of test names to power curve objects
test_curves <- list(
  AD = power_curves_AD,
  KS = power_curves_KS,
  CvM = power_curves_CvM,
  `Chi-Square` = power_curves_Chisq
)

# Loop through each alpha to generate plots
for (alpha in alpha_values) {
  plot(NULL,
       xlim = c(10, max(sapply(test_curves, function(curve) max(curve[[paste0("alpha_", alpha)]]$Sample_Size)))),
       ylim = c(0, 1),
       xlab = "Sample Size",
       ylab = "Power",
       main = paste("Power Curve Comparison at α =", alpha))

  for (i in seq_along(test_names)) {
    name <- test_names[i]
    data <- test_curves[[name]][[paste0("alpha_", alpha)]]
    
    # Draw line
    lines(data$Sample_Size, data$Power, col = test_colors[i], lwd = 2)

    # Add markers at intervals to reduce clutter
    marker_idx <- seq(1, nrow(data), by = 2)
    points(data$Sample_Size[marker_idx], data$Power[marker_idx],
           col = test_colors[i], pch = test_pch[i])
  }

  abline(h = 1, col = "gray", lty = 2)

  legend("bottomright", legend = test_names, col = test_colors, pch = test_pch, lwd = 2, title = "Test")
}

#' 
#' 
#' # 1-component LOGNORMAL
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Load the necessary library
library(ltmix)
library(ReIns)
data(secura)
data <- secura$size
library(SMPracticals) 
truncation_point <- 1.2e6  # Replace with your truncation point if applicable

# Fit a 1-component Lognormal mixture model
fit <- ltmm(data, G = 1, distributions = "lognormal", trunc = truncation_point)

aba <- summary(fit)

plot(fit)

# Extract the fitted parameters
parameters <- fit$Pars

# Display the parameter estimates
print(parameters)

# Load necessary libraries
library(ggplot2)
library(gridExtra)

# Parameters for the 1-component lognormal distribution
mu <- 14.3258849  # Mean of the log-transformed data
sigma <- 0.5014714      # Standard deviation of the log-transformed data

# Lognormal PDF function
lognormal_pdf <- function(x, mu, sigma) {
  dlnorm(x, meanlog = mu, sdlog = sigma)
}

# Truncated Lognormal PDF
truncated_lognormal_pdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         lognormal_pdf(x, mu, sigma) / (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Truncated Lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (plnorm(x, meanlog = mu, sdlog = sigma) - plnorm(truncation_point, meanlog = mu, sdlog = sigma)) /
         (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Function to generate random samples from the truncated lognormal distribution
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_level <- 0.05

# Create lists to store plots
plots_null <- list()
plots_alt <- list()

# Loop through each sample size
for (sample_size in sample_sizes) {
  # Initialize vectors to store p-values
  p_values_null <- numeric(n_sims)
  p_values_alt <- numeric(n_sims)
  
  # Null hypothesis p-value simulations
  for (i in 1:n_sims) {
    samples_null <- generate_truncated_lognormal_samples(sample_size, mu, sigma, truncation_point)
    ks_test_null <- ks.test(samples_null, function(q) truncated_lognormal_cdf(q, mu, sigma, truncation_point))
    p_values_null[i] <- ks_test_null$p.value
  }
  
  # Alternative hypothesis p-value simulations (slightly modified parameters)
  alt_mu <- 14  # Slightly shifted mean
  alt_sigma <- 1    # Slightly increased standard deviation
  
  for (i in 1:n_sims) {
    samples_alt <- generate_truncated_lognormal_samples(sample_size, alt_mu, alt_sigma, truncation_point)
    ks_test_alt <- ks.test(samples_alt, function(q) truncated_lognormal_cdf(q, mu, sigma, truncation_point))
    p_values_alt[i] <- ks_test_alt$p.value
  }
  
  # Convert p-values to data frames for ggplot
  df_pvalues_null <- data.frame(p_value = p_values_null)
  df_pvalues_alt <- data.frame(p_value = p_values_alt)
  
# Create histogram for null hypothesis
p_null <- ggplot(df_pvalues_null, aes(x = p_value)) +
  geom_histogram(aes(y = after_stat(count) / sum(after_stat(count))), 
                 bins = 30, fill = "lightblue", color = "black", alpha = 0.7) +
  geom_vline(xintercept = alpha_level, color = "red", size = 1) +
  labs(subtitle = paste("n =", sample_size),
       x = "P-Value",
       y = "Proportion") +
  theme_minimal() +
theme(panel.grid = element_blank(),
      axis.title = element_blank())


# Create histogram for alternative hypothesis
p_alt <- ggplot(df_pvalues_alt, aes(x = p_value)) +
  geom_histogram(aes(y = after_stat(count) / sum(after_stat(count))), 
                 bins = 30, fill = "lightgreen", color = "black", alpha = 0.7) +
  geom_vline(xintercept = alpha_level, color = "red", size = 1) +
  labs(subtitle = paste("n =", sample_size),
       x = "P-Value",
       y = "Proportion") +
theme_minimal() +
theme(panel.grid = element_blank(),
      axis.title = element_blank())
  
  # Store the plots in lists
  plots_null[[as.character(sample_size)]] <- p_null
  plots_alt[[as.character(sample_size)]] <- p_alt
}

# For null plots
grid.arrange(
  arrangeGrob(grobs = plots_null, ncol = 2, nrow = 3),
  top = textGrob("KS", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)


# For alternative plots
grid.arrange(
  arrangeGrob(grobs = plots_alt, ncol = 2, nrow = 3),
  top = textGrob("KS", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)





# Define the lognormal PDF
lognormal_pdf <- function(x, mu, sigma) {
  dlnorm(x, meanlog = mu, sdlog = sigma)
}

# Define the lognormal CDF
lognormal_cdf <- function(x, mu, sigma) {
  plnorm(x, meanlog = mu, sdlog = sigma)
}

# Define the truncated lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (lognormal_cdf(x, mu, sigma) - lognormal_cdf(truncation_point, mu, sigma)) /
         (1 - lognormal_cdf(truncation_point, mu, sigma)))
}

# Parameters for the null model (1-component lognormal)
mu_null <- 14.3258849  # Mean of the log-transformed data
sigma_null <- 0.5014714       # Standard deviation of the log-transformed data
truncation_point <- 1.2e6

# Parameters for the alternative model
mu_alt <- 14    # Slightly shifted mean
sigma_alt <- 1

# Function to generate samples from the truncated lognormal distribution
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 50, 100, 500, 1000, 2000, 2500)
n_sims <- 2000  # Number of simulations
alpha_values <- c(0.01, 0.05, 0.1)  # List of significance levels

# Loop through each alpha value and sample size
for (alpha in alpha_values) {
  
  # Initialize data frame to store results for current alpha
  results <- data.frame(Sample_Size = integer(), Type_I_Error_Rate = numeric(), Power = numeric())
  
  # Loop through each sample size
  for (sample_size in sample_sizes) {
    
    # Initialize counters
    type_I_errors <- 0
    power_count <- 0
    
    # Type I Error Simulation: Null model
    for (i in 1:n_sims) {
      samples_null <- generate_truncated_lognormal_samples(sample_size, mu_null, sigma_null, truncation_point)
      ks_test_null <- ks.test(samples_null, function(q) truncated_lognormal_cdf(q, mu_null, sigma_null, truncation_point))
      if (ks_test_null$p.value < alpha) {
        type_I_errors <- type_I_errors + 1
      }
    }
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_truncated_lognormal_samples(sample_size, mu_alt, sigma_alt, truncation_point)
      ks_test_alt <- ks.test(samples_alt, function(q) truncated_lognormal_cdf(q, mu_null, sigma_null, truncation_point))
      if (ks_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Type I Error Rate and Power for current sample size
    type_I_error_rate <- type_I_errors / n_sims
    power <- power_count / n_sims
    
    # Store results in the data frame
    results <- rbind(results, data.frame(Sample_Size = sample_size, Type_I_Error_Rate = type_I_error_rate, Power = power))
  }
  
  # Print results for the current alpha value
  cat("\nResults for alpha =", alpha, "\n")
  print(results)
}





# Load necessary libraries
library(ggplot2)

# Define the lognormal PDF
lognormal_pdf <- function(x, mu, sigma) {
  dlnorm(x, meanlog = mu, sdlog = sigma)
}

# Define the truncated lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (plnorm(x, meanlog = mu, sdlog = sigma) - plnorm(truncation_point, meanlog = mu, sdlog = sigma)) /
         (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Parameters for the null model
mu_null <- 14.3258849  # Mean of the log-transformed data
sigma_null <- 0.5014714    # Mean of the log-transformed data
truncation_point <- 1.2e6

# Parameters for the alternative model (slightly shifted and widened)
mu_alt <- 14
sigma_alt <- 1

# Function to generate samples from the truncated lognormal distribution
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Simulation settings
n_sims <- 2000
alpha_values <- c(0.01, 0.05, 0.1)
step_size <- 10

# Initialize a list to store power curve data for each alpha
power_curves <- list()

# Loop through each alpha value to compute the power curve
for (alpha in alpha_values) {
  
  # Initialize starting sample size, power, and vectors to store results
  sample_size <- 10
  power <- 0
  sample_sizes <- c()
  power_values <- c()
  
  # Increment sample size until power reaches 1
  while (power < 1) {
    power_count <- 0
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_truncated_lognormal_samples(sample_size, mu_alt, sigma_alt, truncation_point)
      ks_test_alt <- ks.test(samples_alt, function(q) truncated_lognormal_cdf(q, mu_null, sigma_null, truncation_point))
      if (ks_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate power for the current sample size
    power <- power_count / n_sims
    
    # Store the sample size and power values
    sample_sizes <- c(sample_sizes, sample_size)
    power_values <- c(power_values, power)
    
    # Increment sample size if power is less than 1
    if (power < 1) {
      sample_size <- sample_size + step_size
    }
  }
  
  # Store the results for the current alpha value in the list
  power_curves[[paste0("alpha_", alpha)]] <- data.frame(Sample_Size = sample_sizes, Power = power_values)
  
  # Print the minimum sample size where power reaches 1
  min_sample_size_power_1 <- sample_size
  cat("\nMinimum sample size where power reaches 1 for alpha =", alpha, ":", min_sample_size_power_1, "\n")
}

# Plot the Power curves for each alpha
colors <- c("blue", "purple", "green")
plot(NULL, xlim = c(10, max(unlist(lapply(power_curves, function(df) df$Sample_Size)))), 
     ylim = c(0, 1), xlab = "Sample Size", ylab = "Power")

for (i in seq_along(alpha_values)) {
  alpha <- alpha_values[i]
  power_data <- power_curves[[paste0("alpha_", alpha)]]
  lines(power_data$Sample_Size, power_data$Power, col = colors[i], type = "l", lwd = 2)
  abline(h = 1, col = "red", lty = 2)  # Reference line for Power = 1
}

legend("bottomright", legend = paste("Alpha =", alpha_values), col = colors, lwd = 2)

power_curves_KS <- power_curves

#' 
#' 
#' # AD 
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Load necessary libraries
library(ggplot2)
library(gridExtra)

# Parameters for the 1-component lognormal distribution
mu <- 14.3258849  # Mean of the log-transformed data
sigma <- 0.5014714      # Standard deviation of the log-transformed data

# Lognormal PDF function
lognormal_pdf <- function(x, mu, sigma) {
  dlnorm(x, meanlog = mu, sdlog = sigma)
}

# Truncated Lognormal PDF
truncated_lognormal_pdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         lognormal_pdf(x, mu, sigma) / (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Truncated Lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (plnorm(x, meanlog = mu, sdlog = sigma) - plnorm(truncation_point, meanlog = mu, sdlog = sigma)) /
         (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Function to generate random samples from the truncated lognormal distribution
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_level <- 0.05

# Create lists to store plots
plots_null <- list()
plots_alt <- list()

# Loop through each sample size
for (sample_size in sample_sizes) {
  # Initialize vectors to store p-values
  p_values_null <- numeric(n_sims)
  p_values_alt <- numeric(n_sims)
  
  # Null hypothesis p-value simulations
  for (i in 1:n_sims) {
    samples_null <- generate_truncated_lognormal_samples(sample_size, mu, sigma, truncation_point)
    ad_test_null <- ADGofTest::ad.test(samples_null, function(q) truncated_lognormal_cdf(q, mu, sigma, truncation_point))
    p_values_null[i] <- ad_test_null$p.value
  }
  
  # Alternative hypothesis p-value simulations (slightly modified parameters)
  alt_mu <- 14  # Slightly shifted mean
  alt_sigma <- 1     # Slightly increased standard deviation
  
  for (i in 1:n_sims) {
    samples_alt <- generate_truncated_lognormal_samples(sample_size, alt_mu, alt_sigma, truncation_point)
    ad_test_alt <- ADGofTest::ad.test(samples_alt, function(q) truncated_lognormal_cdf(q, mu, sigma, truncation_point))
    p_values_alt[i] <- ad_test_alt$p.value
  }
  
  # Convert p-values to data frames for ggplot
  df_pvalues_null <- data.frame(p_value = p_values_null)
  df_pvalues_alt <- data.frame(p_value = p_values_alt)
  
# Create histogram for null hypothesis
p_null <- ggplot(df_pvalues_null, aes(x = p_value)) +
  geom_histogram(aes(y = after_stat(count) / sum(after_stat(count))), 
                 bins = 30, fill = "lightblue", color = "black", alpha = 0.7) +
  geom_vline(xintercept = alpha_level, color = "red", size = 1) +
  labs(subtitle = paste("n =", sample_size),
       x = "P-Value",
       y = "Proportion") +
  theme_minimal() +
theme(panel.grid = element_blank(),
      axis.title = element_blank())


# Create histogram for alternative hypothesis
p_alt <- ggplot(df_pvalues_alt, aes(x = p_value)) +
  geom_histogram(aes(y = after_stat(count) / sum(after_stat(count))), 
                 bins = 30, fill = "lightgreen", color = "black", alpha = 0.7) +
  geom_vline(xintercept = alpha_level, color = "red", size = 1) +
  labs(subtitle = paste("n =", sample_size),
       x = "P-Value",
       y = "Proportion") +
theme_minimal() +
theme(panel.grid = element_blank(),
      axis.title = element_blank())
  
  # Store the plots in lists
  plots_null[[as.character(sample_size)]] <- p_null
  plots_alt[[as.character(sample_size)]] <- p_alt
}

# For null plots
grid.arrange(
  arrangeGrob(grobs = plots_null, ncol = 2, nrow = 3),
  top = textGrob("AD", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)


# For alternative plots
grid.arrange(
  arrangeGrob(grobs = plots_alt, ncol = 2, nrow = 3),
  top = textGrob("AD", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)





# Define the lognormal PDF
lognormal_pdf <- function(x, mu, sigma) {
  dlnorm(x, meanlog = mu, sdlog = sigma)
}

# Define the lognormal CDF
lognormal_cdf <- function(x, mu, sigma) {
  plnorm(x, meanlog = mu, sdlog = sigma)
}

# Define the truncated lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (lognormal_cdf(x, mu, sigma) - lognormal_cdf(truncation_point, mu, sigma)) /
         (1 - lognormal_cdf(truncation_point, mu, sigma)))
}

# Parameters for the null model (1-component lognormal)
mu_null <- 14.3258849  # Mean of the log-transformed data
sigma_null <- 0.5014714       # Standard deviation of the log-transformed data
truncation_point <- 1.2e6

# Parameters for the alternative model
mu_alt <- 14    # Slightly shifted mean
sigma_alt <- 1

# Function to generate samples from the truncated lognormal distribution
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 50, 100, 500, 1000, 2000, 2500)
n_sims <- 2000  # Number of simulations
alpha_values <- c(0.01, 0.05, 0.1)  # List of significance levels

# Loop through each alpha value and sample size
for (alpha in alpha_values) {
  
  # Initialize data frame to store results for current alpha
  results <- data.frame(Sample_Size = integer(), Type_I_Error_Rate = numeric(), Power = numeric())
  
  # Loop through each sample size
  for (sample_size in sample_sizes) {
    
    # Initialize counters
    type_I_errors <- 0
    power_count <- 0
    
    # Type I Error Simulation: Null model
    for (i in 1:n_sims) {
      samples_null <- generate_truncated_lognormal_samples(sample_size, mu_null, sigma_null, truncation_point)
      ad_test_null <- ADGofTest::ad.test(samples_null, function(q) truncated_lognormal_cdf(q, mu_null, sigma_null, truncation_point))
      if (ad_test_null$p.value < alpha) {
        type_I_errors <- type_I_errors + 1
      }
    }
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_truncated_lognormal_samples(sample_size, mu_alt, sigma_alt, truncation_point)
      ad_test_alt <- ADGofTest::ad.test(samples_alt, function(q) truncated_lognormal_cdf(q, mu_null, sigma_null, truncation_point))
      if (ad_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Type I Error Rate and Power for current sample size
    type_I_error_rate <- type_I_errors / n_sims
    power <- power_count / n_sims
    
    # Store results in the data frame
    results <- rbind(results, data.frame(Sample_Size = sample_size, Type_I_Error_Rate = type_I_error_rate, Power = power))
  }
  
  # Print results for the current alpha value
  cat("\nResults for alpha =", alpha, "\n")
  print(results)
}





# Load necessary libraries
library(ggplot2)

# Define the lognormal PDF
lognormal_pdf <- function(x, mu, sigma) {
  dlnorm(x, meanlog = mu, sdlog = sigma)
}

# Define the truncated lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (plnorm(x, meanlog = mu, sdlog = sigma) - plnorm(truncation_point, meanlog = mu, sdlog = sigma)) /
         (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Parameters for the null model
mu_null <- 14.3258849  # Mean of the log-transformed data
sigma_null <- 0.5014714    # Mean of the log-transformed data
truncation_point <- 1.2e6

# Parameters for the alternative model (slightly shifted and widened)
mu_alt <- 14
sigma_alt <- 1

# Function to generate samples from the truncated lognormal distribution
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Simulation settings
n_sims <- 2000
alpha_values <- c(0.01, 0.05, 0.1)
step_size <- 10

# Initialize a list to store power curve data for each alpha
power_curves <- list()

# Loop through each alpha value to compute the power curve
for (alpha in alpha_values) {
  
  # Initialize starting sample size, power, and vectors to store results
  sample_size <- 10
  power <- 0
  sample_sizes <- c()
  power_values <- c()
  
  # Increment sample size until power reaches 1
  while (power < 1) {
    power_count <- 0
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_truncated_lognormal_samples(sample_size, mu_alt, sigma_alt, truncation_point)
      ad_test_alt <- ADGofTest::ad.test(samples_alt, function(q) truncated_lognormal_cdf(q, mu_null, sigma_null, truncation_point))
      if (ad_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate power for the current sample size
    power <- power_count / n_sims
    
    # Store the sample size and power values
    sample_sizes <- c(sample_sizes, sample_size)
    power_values <- c(power_values, power)
    
    # Increment sample size if power is less than 1
    if (power < 1) {
      sample_size <- sample_size + step_size
    }
  }
  
  # Store the results for the current alpha value in the list
  power_curves[[paste0("alpha_", alpha)]] <- data.frame(Sample_Size = sample_sizes, Power = power_values)
  
  # Print the minimum sample size where power reaches 1
  min_sample_size_power_1 <- sample_size
  cat("\nMinimum sample size where power reaches 1 for alpha =", alpha, ":", min_sample_size_power_1, "\n")
}

# Plot the Power curves for each alpha
colors <- c("blue", "purple", "green")
plot(NULL, xlim = c(10, max(unlist(lapply(power_curves, function(df) df$Sample_Size)))), 
     ylim = c(0, 1), xlab = "Sample Size", ylab = "Power")

for (i in seq_along(alpha_values)) {
  alpha <- alpha_values[i]
  power_data <- power_curves[[paste0("alpha_", alpha)]]
  lines(power_data$Sample_Size, power_data$Power, col = colors[i], type = "l", lwd = 2)
  abline(h = 1, col = "red", lty = 2)  # Reference line for Power = 1
}

legend("bottomright", legend = paste("Alpha =", alpha_values), col = colors, lwd = 2)

power_curves_AD <- power_curves

#' 
#' 
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Load necessary libraries
library(ggplot2)
library(gridExtra)

# Parameters for the 1-component lognormal distribution
mu <- 14.3258849  # Mean of the log-transformed data
sigma <- 0.5014714      # Standard deviation of the log-transformed data

# Lognormal PDF function
lognormal_pdf <- function(x, mu, sigma) {
  dlnorm(x, meanlog = mu, sdlog = sigma)
}

# Truncated Lognormal PDF
truncated_lognormal_pdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         lognormal_pdf(x, mu, sigma) / (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Truncated Lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (plnorm(x, meanlog = mu, sdlog = sigma) - plnorm(truncation_point, meanlog = mu, sdlog = sigma)) /
         (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Function to generate random samples from the truncated lognormal distribution
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_level <- 0.05

# Create lists to store plots
plots_null <- list()
plots_alt <- list()

# Loop through each sample size
for (sample_size in sample_sizes) {
  # Initialize vectors to store p-values
  p_values_null <- numeric(n_sims)
  p_values_alt <- numeric(n_sims)
  
  # Null hypothesis p-value simulations
  for (i in 1:n_sims) {
    samples_null <- generate_truncated_lognormal_samples(sample_size, mu, sigma, truncation_point)
    cvm_test_null <- goftest::cvm.test(samples_null, function(q) truncated_lognormal_cdf(q, mu, sigma, truncation_point))
    p_values_null[i] <- cvm_test_null$p.value
  }
  
  # Alternative hypothesis p-value simulations (slightly modified parameters)
  alt_mu <- 14  # Slightly shifted mean
  alt_sigma <- 1     # Slightly increased standard deviation
  
  for (i in 1:n_sims) {
    samples_alt <- generate_truncated_lognormal_samples(sample_size, alt_mu, alt_sigma, truncation_point)
    cvm_test_alt <- goftest::cvm.test(samples_alt, function(q) truncated_lognormal_cdf(q, mu, sigma, truncation_point))
    p_values_alt[i] <- cvm_test_alt$p.value
  }
  
  # Convert p-values to data frames for ggplot
  df_pvalues_null <- data.frame(p_value = p_values_null)
  df_pvalues_alt <- data.frame(p_value = p_values_alt)
  
# Create histogram for null hypothesis
p_null <- ggplot(df_pvalues_null, aes(x = p_value)) +
  geom_histogram(aes(y = after_stat(count) / sum(after_stat(count))), 
                 bins = 30, fill = "lightblue", color = "black", alpha = 0.7) +
  geom_vline(xintercept = alpha_level, color = "red", size = 1) +
  labs(subtitle = paste("n =", sample_size),
       x = "P-Value",
       y = "Proportion") +
  theme_minimal() +
theme(panel.grid = element_blank(),
      axis.title = element_blank())


# Create histogram for alternative hypothesis
p_alt <- ggplot(df_pvalues_alt, aes(x = p_value)) +
  geom_histogram(aes(y = after_stat(count) / sum(after_stat(count))), 
                 bins = 30, fill = "lightgreen", color = "black", alpha = 0.7) +
  geom_vline(xintercept = alpha_level, color = "red", size = 1) +
  labs(subtitle = paste("n =", sample_size),
       x = "P-Value",
       y = "Proportion") +
theme_minimal() +
theme(panel.grid = element_blank(),
      axis.title = element_blank())
  
  # Store the plots in lists
  plots_null[[as.character(sample_size)]] <- p_null
  plots_alt[[as.character(sample_size)]] <- p_alt
}

# For null plots
grid.arrange(
  arrangeGrob(grobs = plots_null, ncol = 2, nrow = 3),
  top = textGrob("CvM", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)


# For alternative plots
grid.arrange(
  arrangeGrob(grobs = plots_alt, ncol = 2, nrow = 3),
  top = textGrob("CvM", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)





# Define the lognormal PDF
lognormal_pdf <- function(x, mu, sigma) {
  dlnorm(x, meanlog = mu, sdlog = sigma)
}

# Define the lognormal CDF
lognormal_cdf <- function(x, mu, sigma) {
  plnorm(x, meanlog = mu, sdlog = sigma)
}

# Define the truncated lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (lognormal_cdf(x, mu, sigma) - lognormal_cdf(truncation_point, mu, sigma)) /
         (1 - lognormal_cdf(truncation_point, mu, sigma)))
}

# Parameters for the null model (1-component lognormal)
mu_null <- 14.3258849  # Mean of the log-transformed data
sigma_null <- 0.5014714       # Standard deviation of the log-transformed data
truncation_point <- 1.2e6

# Parameters for the alternative model
mu_alt <- 14    # Slightly shifted mean
sigma_alt <- 1

# Function to generate samples from the truncated lognormal distribution
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 50, 100, 500, 1000, 2000, 2500)
n_sims <- 2000  # Number of simulations
alpha_values <- c(0.01, 0.05, 0.1)  # List of significance levels

# Loop through each alpha value and sample size
for (alpha in alpha_values) {
  
  # Initialize data frame to store results for current alpha
  results <- data.frame(Sample_Size = integer(), Type_I_Error_Rate = numeric(), Power = numeric())
  
  # Loop through each sample size
  for (sample_size in sample_sizes) {
    
    # Initialize counters
    type_I_errors <- 0
    power_count <- 0
    
    # Type I Error Simulation: Null model
    for (i in 1:n_sims) {
      samples_null <- generate_truncated_lognormal_samples(sample_size, mu_null, sigma_null, truncation_point)
      cvm_test_null <- goftest::cvm.test(samples_null, function(q) truncated_lognormal_cdf(q, mu_null, sigma_null, truncation_point))
      if (cvm_test_null$p.value < alpha) {
        type_I_errors <- type_I_errors + 1
      }
    }
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_truncated_lognormal_samples(sample_size, mu_alt, sigma_alt, truncation_point)
      cvm_test_alt <- goftest::cvm.test(samples_alt, function(q) truncated_lognormal_cdf(q, mu_null, sigma_null, truncation_point))
      if (cvm_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Type I Error Rate and Power for current sample size
    type_I_error_rate <- type_I_errors / n_sims
    power <- power_count / n_sims
    
    # Store results in the data frame
    results <- rbind(results, data.frame(Sample_Size = sample_size, Type_I_Error_Rate = type_I_error_rate, Power = power))
  }
  
  # Print results for the current alpha value
  cat("\nResults for alpha =", alpha, "\n")
  print(results)
}





# Load necessary libraries
library(ggplot2)

# Define the lognormal PDF
lognormal_pdf <- function(x, mu, sigma) {
  dlnorm(x, meanlog = mu, sdlog = sigma)
}

# Define the truncated lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (plnorm(x, meanlog = mu, sdlog = sigma) - plnorm(truncation_point, meanlog = mu, sdlog = sigma)) /
         (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Parameters for the null model
mu_null <- 14.3258849  # Mean of the log-transformed data
sigma_null <- 0.5014714    # Mean of the log-transformed data
truncation_point <- 1.2e6

# Parameters for the alternative model (slightly shifted and widened)
mu_alt <- 14
sigma_alt <- 1

# Function to generate samples from the truncated lognormal distribution
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Simulation settings
n_sims <- 2000
alpha_values <- c(0.01, 0.05, 0.1)
step_size <- 10

# Initialize a list to store power curve data for each alpha
power_curves <- list()

# Loop through each alpha value to compute the power curve
for (alpha in alpha_values) {
  
  # Initialize starting sample size, power, and vectors to store results
  sample_size <- 10
  power <- 0
  sample_sizes <- c()
  power_values <- c()
  
  # Increment sample size until power reaches 1
  while (power < 1) {
    power_count <- 0
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_truncated_lognormal_samples(sample_size, mu_alt, sigma_alt, truncation_point)
      cvm_test_alt <- goftest::cvm.test(samples_alt, function(q) truncated_lognormal_cdf(q, mu_null, sigma_null, truncation_point))
      if (cvm_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate power for the current sample size
    power <- power_count / n_sims
    
    # Store the sample size and power values
    sample_sizes <- c(sample_sizes, sample_size)
    power_values <- c(power_values, power)
    
    # Increment sample size if power is less than 1
    if (power < 1) {
      sample_size <- sample_size + step_size
    }
  }
  
  # Store the results for the current alpha value in the list
  power_curves[[paste0("alpha_", alpha)]] <- data.frame(Sample_Size = sample_sizes, Power = power_values)
  
  # Print the minimum sample size where power reaches 1
  min_sample_size_power_1 <- sample_size
  cat("\nMinimum sample size where power reaches 1 for alpha =", alpha, ":", min_sample_size_power_1, "\n")
}

# Plot the Power curves for each alpha
colors <- c("blue", "purple", "green")
plot(NULL, xlim = c(10, max(unlist(lapply(power_curves, function(df) df$Sample_Size)))), 
     ylim = c(0, 1), xlab = "Sample Size", ylab = "Power")

for (i in seq_along(alpha_values)) {
  alpha <- alpha_values[i]
  power_data <- power_curves[[paste0("alpha_", alpha)]]
  lines(power_data$Sample_Size, power_data$Power, col = colors[i], type = "l", lwd = 2)
  abline(h = 1, col = "red", lty = 2)  # Reference line for Power = 1
}

legend("bottomright", legend = paste("Alpha =", alpha_values), col = colors, lwd = 2)

power_curves_CvM <- power_curves

#' 
#' 
#' #ChiSquare
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Load necessary libraries
library(ggplot2)
library(gridExtra)

# Parameters for the lognormal distribution
mu <- 14.3258849  # Mean of the log-transformed data
sigma <- 0.5014714  # Standard deviation of the log-transformed data
truncation_point <- 1.2e6  # Define truncation point for truncated lognormal

# Truncated Lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (plnorm(x, meanlog = mu, sdlog = sigma) - plnorm(truncation_point, meanlog = mu, sdlog = sigma)) /
         (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Function to generate truncated lognormal samples efficiently
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples[1:n])  # Return exactly `n` samples
}

# Dynamic binning function
dynamic_binning <- function(data) {
  num_bins <- max(10, floor(1 + log2(length(data))))  # Sturges' formula
  bin_edges <- quantile(data, probs = seq(0, 1, length.out = num_bins + 1))
  observed <- hist(data, breaks = bin_edges, plot = FALSE)$counts
  return(list(observed = observed, bin_edges = bin_edges))
}

# Chi-Square Test with Dynamic Binning
chi_square_test_dynamic <- function(data, cdf_func, mu, sigma, truncation_point) {
  bins <- dynamic_binning(data)
  
  expected <- sapply(1:(length(bins$bin_edges) - 1), function(i) {
    p1 <- cdf_func(bins$bin_edges[i], mu, sigma, truncation_point)
    p2 <- cdf_func(bins$bin_edges[i + 1], mu, sigma, truncation_point)
    length(data) * (p2 - p1)
  })
  
  chisq.test(bins$observed, p = expected / sum(expected), rescale.p = TRUE)
}

# Simulation settings
sample_sizes <- c(10, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_level <- 0.05

# Alternative hypothesis parameters
alt_mu <- 14  # Slightly shifted mean
alt_sigma <- 1  # Slightly increased standard deviation

# Function to simulate Chi-Square GoF test p-values
simulate_chisq_p_values <- function(sample_size, n_sims, mu, sigma, alt_mu, alt_sigma, truncation_point) {
  # Null hypothesis simulation
  p_values_null <- replicate(n_sims, {
    samples_null <- generate_truncated_lognormal_samples(sample_size, mu, sigma, truncation_point)
    chi_square_test_dynamic(samples_null, truncated_lognormal_cdf, mu, sigma, truncation_point)$p.value
  })
  
  # Alternative hypothesis simulation
  p_values_alt <- replicate(n_sims, {
    samples_alt <- generate_truncated_lognormal_samples(sample_size, alt_mu, alt_sigma, truncation_point)
    chi_square_test_dynamic(samples_alt, truncated_lognormal_cdf, mu, sigma, truncation_point)$p.value
  })
  
  list(null = p_values_null, alt = p_values_alt)
}

# Collect p-values for each sample size
p_values_null <- list()
p_values_alt <- list()

for (sample_size in sample_sizes) {
  results <- simulate_chisq_p_values(sample_size, n_sims, mu, sigma, alt_mu, alt_sigma, truncation_point)
  
  # Store results
  p_values_null[[as.character(sample_size)]] <- results$null
  p_values_alt[[as.character(sample_size)]] <- results$alt
}

plot_p_values <- function(p_values, sample_sizes, hypothesis, color) {
  plots <- list()
  for (sample_size in sample_sizes) {
    p_data <- data.frame(p_value = p_values[[as.character(sample_size)]])
    plot <- ggplot(p_data, aes(x = p_value)) +
      geom_histogram(aes(y = after_stat(count / sum(count))), 
                     bins = 30, fill = color, color = "black", alpha = 0.7) +
      geom_vline(xintercept = alpha_level, color = "red", size = 1) +
      labs(subtitle = paste("n =", sample_size)) +
      scale_x_continuous(limits = c(0, 1)) +
      theme_minimal() +
      theme(
      panel.grid = element_blank(),
      axis.title = element_blank()
)
    plots[[as.character(sample_size)]] <- plot
  }
  return(plots)
}

# Generate histograms for null and alternative hypotheses
plots_null <- plot_p_values(p_values_null, sample_sizes, "Null Hypothesis", color = "lightblue")
plots_alt <- plot_p_values(p_values_alt, sample_sizes, "Alternative Hypothesis", color = "lightgreen")


# For null plots
grid.arrange(
  arrangeGrob(grobs = plots_null, ncol = 2, nrow = 3),
  top = textGrob("CHI-SQUARE", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)


# For alternative plots
grid.arrange(
  arrangeGrob(grobs = plots_alt, ncol = 2, nrow = 3),
  top = textGrob("CHI-SQUARE", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Proportion", rot = 90, gp = gpar(fontsize = 13))
)



# Load necessary libraries
library(ggplot2)

# Lognormal CDF Function
lognormal_cdf <- function(x, mu, sigma) {
  plnorm(x, meanlog = mu, sdlog = sigma)
}

# Truncated Lognormal CDF Function
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (lognormal_cdf(x, mu, sigma) - lognormal_cdf(truncation_point, mu, sigma)) /
         (1 - lognormal_cdf(truncation_point, mu, sigma)))
}

# Function to Generate Truncated Lognormal Samples
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Dynamic Binning Function
dynamic_binning <- function(data) {
  num_bins <- max(10, floor(1 + log2(length(data))))  # Sturges' formula
  bin_edges <- quantile(data, probs = seq(0, 1, length.out = num_bins + 1))
  observed <- hist(data, breaks = bin_edges, plot = FALSE)$counts
  return(list(observed = observed, bin_edges = bin_edges))
}

# Chi-Square Test with Dynamic Binning
chi_square_test_dynamic <- function(data, cdf_func, mu, sigma, truncation_point) {
  bins <- dynamic_binning(data)
  
  expected <- sapply(1:(length(bins$bin_edges) - 1), function(i) {
    p1 <- cdf_func(bins$bin_edges[i], mu, sigma, truncation_point)
    p2 <- cdf_func(bins$bin_edges[i + 1], mu, sigma, truncation_point)
    length(data) * (p2 - p1)
  })
  
  chisq.test(bins$observed, p = expected / sum(expected), rescale.p = TRUE)
}

# Parameters for Null and Alternative Models
mu_null <- 14.3258849
sigma_null <- 0.5014714
truncation_point <- 1.2e6

mu_alt <- 14
sigma_alt <- 1

# Simulation Settings
sample_sizes <- c(10, 50, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_values <- c(0.01, 0.05, 0.1)

# Store Results
all_results <- data.frame()

# Loop Through Each Alpha Value
for (alpha in alpha_values) {
  # Loop Through Each Sample Size
  for (sample_size in sample_sizes) {
    # Initialize Counters
    type_I_errors <- 0
    power_count <- 0
    
    # Type I Error Simulation (Null Hypothesis)
    for (i in 1:n_sims) {
      samples_null <- generate_truncated_lognormal_samples(sample_size, mu_null, sigma_null, truncation_point)
      chi_sq_null <- chi_square_test_dynamic(samples_null, truncated_lognormal_cdf, mu_null, sigma_null, truncation_point)
      if (chi_sq_null$p.value < alpha) {
        type_I_errors <- type_I_errors + 1
      }
    }
    
    # Power Simulation (Alternative Hypothesis)
    for (i in 1:n_sims) {
      samples_alt <- generate_truncated_lognormal_samples(sample_size, mu_alt, sigma_alt, truncation_point)
      chi_sq_alt <- chi_square_test_dynamic(samples_alt, truncated_lognormal_cdf, mu_null, sigma_null, truncation_point)
      if (chi_sq_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Metrics
    type_I_error_rate <- type_I_errors / n_sims
    power <- power_count / n_sims
    
    # Append Results
    all_results <- rbind(all_results, data.frame(
      Alpha = alpha,
      Sample_Size = sample_size,
      Type_I_Error_Rate = type_I_error_rate,
      Power = power
    ))
  }
}

# Print Results
print(all_results)






# Load necessary libraries
library(ggplot2)

# Lognormal CDF Function
lognormal_cdf <- function(x, mu, sigma) {
  plnorm(x, meanlog = mu, sdlog = sigma)
}

# Truncated Lognormal CDF Function
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (lognormal_cdf(x, mu, sigma) - lognormal_cdf(truncation_point, mu, sigma)) /
         (1 - lognormal_cdf(truncation_point, mu, sigma)))
}

# Function to Generate Truncated Lognormal Samples
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Dynamic Binning Function
dynamic_binning <- function(data) {
  num_bins <- max(10, floor(1 + log2(length(data))))  # Sturges' formula
  bin_edges <- quantile(data, probs = seq(0, 1, length.out = num_bins + 1))
  observed <- hist(data, breaks = bin_edges, plot = FALSE)$counts
  return(list(observed = observed, bin_edges = bin_edges))
}

# Chi-Square Test with Dynamic Binning
chi_square_test_dynamic <- function(data, cdf_func, mu, sigma, truncation_point) {
  bins <- dynamic_binning(data)
  
  expected <- sapply(1:(length(bins$bin_edges) - 1), function(i) {
    p1 <- cdf_func(bins$bin_edges[i], mu, sigma, truncation_point)
    p2 <- cdf_func(bins$bin_edges[i + 1], mu, sigma, truncation_point)
    length(data) * (p2 - p1)
  })
  
  chisq.test(bins$observed, p = expected / sum(expected), rescale.p = TRUE)
}

# Parameters for Null and Alternative Models
mu_null <- 14.3258849
sigma_null <- 0.5014714
truncation_point <- 1.2e6

mu_alt <- 14
sigma_alt <- 1

# Simulation Settings
n_sims <- 2000
alpha_values <- c(0.01, 0.05, 0.1)
step_size <- 10  # Increment in sample size

# Initialize a list to store power curve data for each alpha
power_curves <- list()

# Loop Through Each Alpha Value
for (alpha in alpha_values) {
  # Initialize variables for tracking sample size and power
  sample_size <- 10
  power <- 0
  sample_sizes <- c()
  power_values <- c()
  
  # Increment sample size until power reaches 1
  while (power < 1) {
    power_count <- 0
    
    # Power Simulation: Alternative Hypothesis
    for (i in 1:n_sims) {
      samples_alt <- generate_truncated_lognormal_samples(sample_size, mu_alt, sigma_alt, truncation_point)
      chi_sq_alt <- chi_square_test_dynamic(samples_alt, truncated_lognormal_cdf, mu_null, sigma_null, truncation_point)
      if (chi_sq_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Power for the Current Sample Size
    power <- power_count / n_sims
    
    # Store the Sample Size and Power Values
    sample_sizes <- c(sample_sizes, sample_size)
    power_values <- c(power_values, power)
    
    # Increment Sample Size if Power is Less Than 1
    if (power < 1) {
      sample_size <- sample_size + step_size
    }
  }
  
  # Store the Results for the Current Alpha Value in the List
  power_curves[[paste0("alpha_", alpha)]] <- data.frame(Sample_Size = sample_sizes, Power = power_values)
  
  # Print the Minimum Sample Size Where Power Reaches 1
  min_sample_size_power_1 <- sample_size
  cat("\nMinimum sample size where power reaches 1 for alpha =", alpha, ":", min_sample_size_power_1, "\n")
}

# Plot the Power Curves for Each Alpha
colors <- c("blue", "purple", "green")
plot(NULL, xlim = c(10, max(unlist(lapply(power_curves, function(df) df$Sample_Size)))), 
     ylim = c(0, 1), xlab = "Sample Size", ylab = "Power")

for (i in seq_along(alpha_values)) {
  alpha <- alpha_values[i]
  power_data <- power_curves[[paste0("alpha_", alpha)]]
  lines(power_data$Sample_Size, power_data$Power, col = colors[i], type = "l", lwd = 2)
  abline(h = 1, col = "red", lty = 2)  # Reference line for Power = 1
}

legend("bottomright", legend = paste("Alpha =", alpha_values), col = colors, lwd = 2)

power_curves_Chisq <- power_curves

#' 
#' ### All at different alpha-level
## ----warning=FALSE, echo=TRUE----------------------------------------------------------
# Colorblind-friendly colors and markers
test_names <- c("AD", "KS", "CvM", "Chi-Square")
test_colors <- c("#D55E00", "#0072B2", "#009E73", "#CC79A7")
test_pch <- c(16, 17, 15, 18)

# Explicit mapping of test names to power curve objects
test_curves <- list(
  AD = power_curves_AD,
  KS = power_curves_KS,
  CvM = power_curves_CvM,
  `Chi-Square` = power_curves_Chisq
)

# Loop through each alpha to generate plots
for (alpha in alpha_values) {
  plot(NULL,
       xlim = c(10, max(sapply(test_curves, function(curve) max(curve[[paste0("alpha_", alpha)]]$Sample_Size)))),
       ylim = c(0, 1),
       xlab = "Sample Size",
       ylab = "Power",
       main = paste("Power Curve Comparison at α =", alpha))

  for (i in seq_along(test_names)) {
    name <- test_names[i]
    data <- test_curves[[name]][[paste0("alpha_", alpha)]]
    
    # Draw line
    lines(data$Sample_Size, data$Power, col = test_colors[i], lwd = 2)

    # Add markers at intervals to reduce clutter
    marker_idx <- seq(1, nrow(data), by = 2)
    points(data$Sample_Size[marker_idx], data$Power[marker_idx],
           col = test_colors[i], pch = test_pch[i])
  }

  abline(h = 1, col = "gray", lty = 2)

  legend("bottomright", legend = test_names, col = test_colors, pch = test_pch, lwd = 2, title = "Test")
}

