
rm(list = ls())
library(SMPracticals)
library(actuar)
library(ggplot2)
library(goftest)
library(gridExtra)
library(grid)
data(danish)

set.seed(123456789)

# Load necessary libraries
library(ggplot2)

# Define the Burr distribution density function
burr_pdf <- function(x, alpha, theta, gamma) {
  # Formula for the probability density function of the Burr distribution
  (alpha * gamma * (x / theta)^gamma) / (x * (1 + (x / theta)^gamma)^(alpha + 1))
}

# Function to calculate the CDF of a Burr distribution
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# Parameters for the first and second Burr components from your table
# Component 1: Burr(0.207175, 1.236993, 7.047898)
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634  # Weight for Component 1

# Component 2: Burr(0.028161, 0.856898, 50.277542)
alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 0.602366  # Weight for Component 2

# Generate a sequence of x values to plot the density
x_vals <- seq(0.01, 10, by = 0.01)

# Calculate the weighted density of each component by multiplying the density by its weight
density1 <- pi1 * burr_pdf(x_vals, alpha1, theta1, gamma1)  # Weighted Component 1 density
density2 <- pi2 * burr_pdf(x_vals, alpha2, theta2, gamma2)  # Weighted Component 2 density

# Calculate the weighted density of each component by multiplying the density by its weight
cdf1 <- pi1 * burr_cdf(x_vals, alpha1, theta1, gamma1)  # Weighted Component 1 density
cdf2 <- pi2 * burr_cdf(x_vals, alpha2, theta2, gamma2)  # Weighted Component 2 density


# Mixture density function (weighted sum of the two component densities)
mixture_density <- density1 + density2  # Combine the weighted densities

# Mixture density function (weighted sum of the two component densities)
cdfmixture_density <- cdf1 + cdf2  # Combine the weighted densities

# Create a data frame for plotting
df <- data.frame(
  x = rep(x_vals, 3),  # Repeat x values for all three distributions
  y = c(density1, density2, mixture_density),  # Combine all y values for the densities
  Distribution = factor(rep(c("1-Component", "2-Component", "Mixture"), each = length(x_vals)))
  # Define the labels for each distribution in the plot
)

# Plot the density functions of the two components and the mixture
# ggplot(df, aes(x = x, y = y, color = Distribution, linetype = Distribution)) + 
#   geom_line(size = 1) +  # Plot each line with the specified size
#   scale_color_manual(values = c("blue", "red", "black")) +  # Assign specific colors to components
#   scale_linetype_manual(values = c("dashed", "dashed", "solid")) +  # Set linetypes: dashed for components, solid for mixture
#   labs(x = "x", y = "Density") +  # Set plot title and axis labels
#   theme_minimal() +  # Use a minimal theme for the plot
#   theme(legend.title = element_blank())  # Remove legend title for a cleaner look

# Create a data frame for plotting
cdf <- data.frame(
  x = rep(x_vals, 3),  # Repeat x values for all three distributions
  y = c(cdf1, cdf2, cdfmixture_density),  # Combine all y values for the densities
  Distribution = factor(rep(c("1-Component", "2-Component", "Mixture"), each = length(x_vals)))
  # Define the labels for each distribution in the plot
)

# Plot the cumulative density functions of the two components and the mixture
# ggplot(cdf, aes(x = x, y = y, color = Distribution, linetype = Distribution)) + 
#   geom_line(size = 1) +  # Plot each line with the specified size
#   scale_color_manual(values = c("blue", "red", "black")) +  # Assign specific colors to components
#   scale_linetype_manual(values = c("dashed", "dashed", "solid")) +  # Set linetypes: dashed for components, solid for mixture
#   labs(title = "CDF Plots of 1-Component, 2-Component and Mixture Burr", 
#        x = "x", y = "Density") +  # Set plot title and axis labels
#   theme_minimal() +  # Use a minimal theme for the plot
#   theme(legend.title = element_blank())  # Remove legend title for a cleaner look


# Function to generate random samples from a Burr distribution
rburr <- function(n, alpha, theta, gamma) {
  u <- runif(n)  # Generate 'n' uniform random numbers
  theta * ((1 - u)^(-1 / alpha) - 1)^(1 / gamma)  # Inverse CDF for Burr distribution
}

# Function to generate random samples from a mixture of two Burr distributions
rburr_mixture <- function(n, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  # Generate 'n' uniform random numbers between 0 and 1 for component selection
  component <- runif(n)
  
  # Initialize a vector to store the samples
  samples <- numeric(n)
  
  # Select samples from Component 1 based on the mixture probability pi1
  samples[component < pi1] <- rburr(sum(component < pi1), alpha1, theta1, gamma1)
  
  # Select samples from Component 2 based on the mixture probability pi2
  samples[component >= pi1] <- rburr(sum(component >= pi1), alpha2, theta2, gamma2)
  
  return(samples)  # Return the mixture samples
}


# Generate 1000 samples from the mixture of two Burr distributions
n <- 1000
mixture_sample <- rburr_mixture(n, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2)

# Split the samples based on their original component to create individual component samples
# (this step is optional and used here to separate the two components for plotting)
component <- runif(n)
sample1 <- mixture_sample[component < pi1]
sample2 <- mixture_sample[component >= pi1]

# Create data frames for plotting
df1 <- data.frame(x = sample1, Distribution = "1-Component")
df2 <- data.frame(x = sample2, Distribution = "2-Component")
df_mixture <- data.frame(x = mixture_sample, Distribution = "Mixture")

# Combine the data frames
df_combined <- rbind(df1, df2, df_mixture)

# Plot histograms for the components and the mixture in a grid
p <- ggplot(df_combined, aes(x = x)) +
  geom_histogram(aes(y = ..density..), bins = 30, fill = "skyblue", color = "black", alpha = 0.7) +
  facet_grid(~ Distribution) + 
  labs(title = "Histograms for Burr Distribution Components and Mixture", x = "x", y = "Density") +
  theme_minimal()

# Display the grid of histograms
# p

# Dynamic Equal-Frequency Binning Function
dynamic_binning <- function(data) {
  # Determine the number of bins dynamically using Sturges' formula
  num_bins <- max(10, floor(1 + log2(length(data))))  # At least 10 bins
  bin_edges <- quantile(data, probs = seq(0, 1, length.out = num_bins + 1))
  
  # Calculate observed frequencies
  observed <- hist(data, breaks = bin_edges, plot = FALSE)$counts
  
  return(list(observed = observed, bin_edges = bin_edges))
}

# Chi-Square Test with Dynamic Binning
chi_square_test_dynamic <- function(data, cdf_func, params) {
  # Get dynamically determined bins
  bins <- dynamic_binning(data)
  
  # Extract parameters from the list
  alpha1 <- params$alpha1
  theta1 <- params$theta1
  gamma1 <- params$gamma1
  alpha2 <- params$alpha2
  theta2 <- params$theta2
  gamma2 <- params$gamma2
  pi1 <- params$pi1
  pi2 <- 1 - pi1  # Calculate pi2 from pi1
  
  # Calculate expected frequencies
  expected <- sapply(1:(length(bins$bin_edges) - 1), function(i) {
    p1 <- cdf_func(bins$bin_edges[i], alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2)
    p2 <- cdf_func(bins$bin_edges[i + 1], alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2)
    length(data) * (p2 - p1)
  })
  
  # Safeguard: Check minimum expected count
  if (any(expected < 5)) {
    warning("Some bins have expected counts < 5. Consider further adjustments.")
  }
  
  # Perform Chi-Square test
  return(chisq.test(bins$observed, p = expected / sum(expected), rescale.p = TRUE))
}

# Burr CDF function for a single component
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# Mixture CDF for two Burr distributions
pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the Burr mixture model (null hypothesis)
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634
alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 1 - pi1

params_null <- list(alpha1 = alpha1, theta1 = theta1, gamma1 = gamma1,
                    alpha2 = alpha2, theta2 = theta2, gamma2 = gamma2, pi1 = pi1)

# Parameters for the alternative hypothesis
alt_alpha1 <- 0.2
alt_theta1 <- 1.2
alt_gamma1 <- 7.1
alt_alpha2 <- 0.02
alt_theta2 <- 0.9
alt_gamma2 <- 50.4

params_alt <- list(alpha1 = alt_alpha1, theta1 = alt_theta1, gamma1 = alt_gamma1,
                   alpha2 = alt_alpha2, theta2 = alt_theta2, gamma2 = alt_gamma2, pi1 = pi1)

# Function to generate samples under the Burr mixture model
generate_burr_mixture_samples <- function(n, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  samples <- ifelse(component == 1,
                    rburr(n, alpha1, theta1, gamma1),
                    rburr(n, alpha2, theta2, gamma2))
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_level <- 0.05

# Initialize lists to store results
p_values_null <- list()
p_values_alt <- list()

# Simulation loop
for (sample_size in sample_sizes) {
  p_values_null[[as.character(sample_size)]] <- numeric(n_sims)
  p_values_alt[[as.character(sample_size)]] <- numeric(n_sims)
  
  for (i in 1:n_sims) {
    # Generate null hypothesis samples
    samples_null <- generate_burr_mixture_samples(sample_size, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2)
    chi_sq_null <- chi_square_test_dynamic(samples_null, pburr_mixture, params_null)
    p_values_null[[as.character(sample_size)]][i] <- chi_sq_null$p.value
    
    # Generate alternative hypothesis samples
    samples_alt <- generate_burr_mixture_samples(sample_size, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2)
    chi_sq_alt <- chi_square_test_dynamic(samples_alt, pburr_mixture, params_null)  # Null params for alt test
    p_values_alt[[as.character(sample_size)]][i] <- chi_sq_alt$p.value
  }
}

# Convert p-values to data frames for visualization
plot_p_values <- function(p_values, sample_sizes, hypothesis, color) {
  plots <- list()
  for (sample_size in sample_sizes) {
    p_data <- data.frame(p_value = p_values[[as.character(sample_size)]])
    plot <- ggplot(p_data, aes(x = p_value)) +
      geom_histogram(bins = 30, fill = color, color = "black", alpha = 0.7) +
      geom_vline(xintercept = alpha_level, color = "red", size = 1) +
      labs(subtitle = paste("n =", sample_size),
           x = "P-Value",
           y = "Frequency") +
      theme_minimal()
    plots[[as.character(sample_size)]] <- plot
  }
  return(plots)
}




# Generate histograms for null and alternative hypotheses with different colors
plots_null <- plot_p_values(p_values_null, sample_sizes, "Null Hypothesis", color = "lightblue")
plots_alt <- plot_p_values(p_values_alt, sample_sizes, "Alternative Hypothesis", color = "lightgreen")


# For null plots
grid.arrange(
  arrangeGrob(grobs = plots_null, ncol = 2, nrow = 3),
  top = textGrob("CHI-SQUARE", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Frequency", rot = 90, gp = gpar(fontsize = 13))
)


# For alternative plots
grid.arrange(
  arrangeGrob(grobs = plots_alt, ncol = 2, nrow = 3),
  top = textGrob("CHI-SQUARE", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Frequency", rot = 90, gp = gpar(fontsize = 13))
)