rm(list = ls())
# Load the necessary library
library(ltmix)
library(grid)
library(ReIns)
data(secura)
data <- secura$size
library(SMPracticals) 

set.seed(123456789)

# Load necessary libraries
library(ggplot2)

# Define the lognormal PDF
lognormal_pdf <- function(x, mu, sigma) {
  dlnorm(x, meanlog = mu, sdlog = sigma)
}

# Define the truncated lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (plnorm(x, meanlog = mu, sdlog = sigma) - plnorm(truncation_point, meanlog = mu, sdlog = sigma)) /
           (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Parameters for the null model
mu_null <- 14.3258849  # Mean of the log-transformed data
sigma_null <- 0.5014714    # Mean of the log-transformed data
truncation_point <- 1.2e6

# Parameters for the alternative model (slightly shifted and widened)
mu_alt <- 14
sigma_alt <- 1

# Function to generate samples from the truncated lognormal distribution
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Simulation settings
n_sims <- 2000
alpha_values <- c(0.01, 0.05, 0.1)
step_size <- 10

# Initialize a list to store power curve data for each alpha
power_curves <- list()

# Loop through each alpha value to compute the power curve
for (alpha in alpha_values) {
  
  # Initialize starting sample size, power, and vectors to store results
  sample_size <- 10
  power <- 0
  sample_sizes <- c()
  power_values <- c()
  
  # Increment sample size until power reaches 1
  while (power < 1) {
    power_count <- 0
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_truncated_lognormal_samples(sample_size, mu_alt, sigma_alt, truncation_point)
      ks_test_alt <- ks.test(samples_alt, function(q) truncated_lognormal_cdf(q, mu_null, sigma_null, truncation_point))
      if (ks_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate power for the current sample size
    power <- power_count / n_sims
    
    # Store the sample size and power values
    sample_sizes <- c(sample_sizes, sample_size)
    power_values <- c(power_values, power)
    
    # Increment sample size if power is less than 1
    if (power < 1) {
      sample_size <- sample_size + step_size
    }
  }
  
  # Store the results for the current alpha value in the list
  power_curves[[paste0("alpha_", alpha)]] <- data.frame(Sample_Size = sample_sizes, Power = power_values)
  
  # Print the minimum sample size where power reaches 1
  min_sample_size_power_1 <- sample_size
  cat("\nMinimum sample size where power reaches 1 for alpha =", alpha, ":", min_sample_size_power_1, "\n")
}

# Plot the Power curves for each alpha
colors <- c("blue", "purple", "green")
plot(NULL, xlim = c(10, max(unlist(lapply(power_curves, function(df) df$Sample_Size)))), 
     ylim = c(0, 1), xlab = "Sample Size", ylab = "Power")

for (i in seq_along(alpha_values)) {
  alpha <- alpha_values[i]
  power_data <- power_curves[[paste0("alpha_", alpha)]]
  lines(power_data$Sample_Size, power_data$Power, col = colors[i], type = "l", lwd = 2)
  abline(h = 1, col = "red", lty = 2)  # Reference line for Power = 1
}

legend("bottomright", legend = paste("Alpha =", alpha_values), col = colors, lwd = 2)

power_curves_KS <- power_curves