rm(list=ls())
# Load the necessary library
library(ltmix)
library(ReIns)
data(secura)
data <- secura$size
library(SMPracticals) 

set.seed(123456789)


# Load necessary libraries
library(ggplot2)
library(gridExtra)

# Parameters for the lognormal distribution
mu <- 14.3258849  # Mean of the log-transformed data
sigma <- 0.5014714  # Standard deviation of the log-transformed data
truncation_point <- 1.2e6  # Define truncation point for truncated lognormal

# Truncated Lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (plnorm(x, meanlog = mu, sdlog = sigma) - plnorm(truncation_point, meanlog = mu, sdlog = sigma)) /
           (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Function to generate truncated lognormal samples efficiently
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples[1:n])  # Return exactly `n` samples
}

# Dynamic binning function
dynamic_binning <- function(data) {
  num_bins <- max(10, floor(1 + log2(length(data))))  # Sturges' formula
  bin_edges <- quantile(data, probs = seq(0, 1, length.out = num_bins + 1))
  observed <- hist(data, breaks = bin_edges, plot = FALSE)$counts
  return(list(observed = observed, bin_edges = bin_edges))
}

# Chi-Square Test with Dynamic Binning
chi_square_test_dynamic <- function(data, cdf_func, mu, sigma, truncation_point) {
  bins <- dynamic_binning(data)
  
  expected <- sapply(1:(length(bins$bin_edges) - 1), function(i) {
    p1 <- cdf_func(bins$bin_edges[i], mu, sigma, truncation_point)
    p2 <- cdf_func(bins$bin_edges[i + 1], mu, sigma, truncation_point)
    length(data) * (p2 - p1)
  })
  
  chisq.test(bins$observed, p = expected / sum(expected), rescale.p = TRUE)
}

# Simulation settings
sample_sizes <- c(10, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_level <- 0.05

# Alternative hypothesis parameters
alt_mu <- 14  # Slightly shifted mean
alt_sigma <- 1  # Slightly increased standard deviation

# Function to simulate Chi-Square GoF test p-values
simulate_chisq_p_values <- function(sample_size, n_sims, mu, sigma, alt_mu, alt_sigma, truncation_point) {
  # Null hypothesis simulation
  p_values_null <- replicate(n_sims, {
    samples_null <- generate_truncated_lognormal_samples(sample_size, mu, sigma, truncation_point)
    chi_square_test_dynamic(samples_null, truncated_lognormal_cdf, mu, sigma, truncation_point)$p.value
  })
  
  # Alternative hypothesis simulation
  p_values_alt <- replicate(n_sims, {
    samples_alt <- generate_truncated_lognormal_samples(sample_size, alt_mu, alt_sigma, truncation_point)
    chi_square_test_dynamic(samples_alt, truncated_lognormal_cdf, mu, sigma, truncation_point)$p.value
  })
  
  list(null = p_values_null, alt = p_values_alt)
}

# Collect p-values for each sample size
p_values_null <- list()
p_values_alt <- list()

for (sample_size in sample_sizes) {
  results <- simulate_chisq_p_values(sample_size, n_sims, mu, sigma, alt_mu, alt_sigma, truncation_point)
  
  # Store results
  p_values_null[[as.character(sample_size)]] <- results$null
  p_values_alt[[as.character(sample_size)]] <- results$alt
}

# Convert p-values to data frames for visualization
plot_p_values <- function(p_values, sample_sizes, hypothesis, color) {
  plots <- list()
  for (sample_size in sample_sizes) {
    p_data <- data.frame(p_value = p_values[[as.character(sample_size)]])
    plot <- ggplot(p_data, aes(x = p_value)) +
      geom_histogram(bins = 30, fill = color, color = "black", alpha = 0.7) +
      geom_vline(xintercept = alpha_level, color = "red", size = 1) +
      labs(subtitle = paste("n =", sample_size),
           x = "P-Value",
           y = "Frequency") +
      theme_minimal()
    plots[[as.character(sample_size)]] <- plot
  }
  return(plots)
}


# Generate histograms for null and alternative hypotheses
plots_null <- plot_p_values(p_values_null, sample_sizes, "Null Hypothesis", color = "lightblue")
plots_alt <- plot_p_values(p_values_alt, sample_sizes, "Alternative Hypothesis", color = "lightgreen")


# For null plots
grid.arrange(
  arrangeGrob(grobs = plots_null, ncol = 2, nrow = 3),
  top = textGrob("CHI-SQUARE", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Frequency", rot = 90, gp = gpar(fontsize = 13))
)


# For alternative plots
grid.arrange(
  arrangeGrob(grobs = plots_alt, ncol = 2, nrow = 3),
  top = textGrob("CHI-SQUARE", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Frequency", rot = 90, gp = gpar(fontsize = 13))
)
