rm(list = ls())

library(SMPracticals)
library(actuar)
library(ggplot2)
library(goftest)
library(gridExtra)
library(grid)
data(danish)

set.seed(123456789)

# Load necessary libraries
library(ggplot2)

# Define the Burr distribution density function
burr_pdf <- function(x, alpha, theta, gamma) {
  # Formula for the probability density function of the Burr distribution
  (alpha * gamma * (x / theta)^gamma) / (x * (1 + (x / theta)^gamma)^(alpha + 1))
}

# Function to calculate the CDF of a Burr distribution
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

# Parameters for the first and second Burr components from your table
# Component 1: Burr(0.207175, 1.236993, 7.047898)
alpha1 <- 0.207175
theta1 <- 1.236993
gamma1 <- 7.047898
pi1 <- 0.397634  # Weight for Component 1

# Component 2: Burr(0.028161, 0.856898, 50.277542)
alpha2 <- 0.028161
theta2 <- 0.856898
gamma2 <- 50.277542
pi2 <- 0.602366  # Weight for Component 2

# Generate a sequence of x values to plot the density
x_vals <- seq(0.01, 10, by = 0.01)

# Calculate the weighted density of each component by multiplying the density by its weight
density1 <- pi1 * burr_pdf(x_vals, alpha1, theta1, gamma1)  # Weighted Component 1 density
density2 <- pi2 * burr_pdf(x_vals, alpha2, theta2, gamma2)  # Weighted Component 2 density

# Calculate the weighted density of each component by multiplying the density by its weight
cdf1 <- pi1 * burr_cdf(x_vals, alpha1, theta1, gamma1)  # Weighted Component 1 density
cdf2 <- pi2 * burr_cdf(x_vals, alpha2, theta2, gamma2)  # Weighted Component 2 density


# Mixture density function (weighted sum of the two component densities)
mixture_density <- density1 + density2  # Combine the weighted densities

# Mixture density function (weighted sum of the two component densities)
cdfmixture_density <- cdf1 + cdf2  # Combine the weighted densities

# Create a data frame for plotting
df <- data.frame(
  x = rep(x_vals, 3),  # Repeat x values for all three distributions
  y = c(density1, density2, mixture_density),  # Combine all y values for the densities
  Distribution = factor(rep(c("1-Component", "2-Component", "Mixture"), each = length(x_vals)))
  # Define the labels for each distribution in the plot
)

# Plot the density functions of the two components and the mixture
# ggplot(df, aes(x = x, y = y, color = Distribution, linetype = Distribution)) + 
#   geom_line(size = 1) +  # Plot each line with the specified size
#   scale_color_manual(values = c("blue", "red", "black")) +  # Assign specific colors to components
#   scale_linetype_manual(values = c("dashed", "dashed", "solid")) +  # Set linetypes: dashed for components, solid for mixture
#   labs(x = "x", y = "Density") +  # Set plot title and axis labels
#   theme_minimal() +  # Use a minimal theme for the plot
#   theme(legend.title = element_blank())  # Remove legend title for a cleaner look

# Create a data frame for plotting
cdf <- data.frame(
  x = rep(x_vals, 3),  # Repeat x values for all three distributions
  y = c(cdf1, cdf2, cdfmixture_density),  # Combine all y values for the densities
  Distribution = factor(rep(c("1-Component", "2-Component", "Mixture"), each = length(x_vals)))
  # Define the labels for each distribution in the plot
)

# Plot the cumulative density functions of the two components and the mixture
# ggplot(cdf, aes(x = x, y = y, color = Distribution, linetype = Distribution)) + 
#   geom_line(size = 1) +  # Plot each line with the specified size
#   scale_color_manual(values = c("blue", "red", "black")) +  # Assign specific colors to components
#   scale_linetype_manual(values = c("dashed", "dashed", "solid")) +  # Set linetypes: dashed for components, solid for mixture
#   labs(title = "CDF Plots of 1-Component, 2-Component and Mixture Burr", 
#        x = "x", y = "Density") +  # Set plot title and axis labels
#   theme_minimal() +  # Use a minimal theme for the plot
#   theme(legend.title = element_blank())  # Remove legend title for a cleaner look


# Function to generate random samples from a Burr distribution
rburr <- function(n, alpha, theta, gamma) {
  u <- runif(n)  # Generate 'n' uniform random numbers
  theta * ((1 - u)^(-1 / alpha) - 1)^(1 / gamma)  # Inverse CDF for Burr distribution
}

# Function to generate random samples from a mixture of two Burr distributions
rburr_mixture <- function(n, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  # Generate 'n' uniform random numbers between 0 and 1 for component selection
  component <- runif(n)
  
  # Initialize a vector to store the samples
  samples <- numeric(n)
  
  # Select samples from Component 1 based on the mixture probability pi1
  samples[component < pi1] <- rburr(sum(component < pi1), alpha1, theta1, gamma1)
  
  # Select samples from Component 2 based on the mixture probability pi2
  samples[component >= pi1] <- rburr(sum(component >= pi1), alpha2, theta2, gamma2)
  
  return(samples)  # Return the mixture samples
}


# Generate 1000 samples from the mixture of two Burr distributions
n <- 1000
mixture_sample <- rburr_mixture(n, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2)

# Split the samples based on their original component to create individual component samples
# (this step is optional and used here to separate the two components for plotting)
component <- runif(n)
sample1 <- mixture_sample[component < pi1]
sample2 <- mixture_sample[component >= pi1]

# Create data frames for plotting
df1 <- data.frame(x = sample1, Distribution = "1-Component")
df2 <- data.frame(x = sample2, Distribution = "2-Component")
df_mixture <- data.frame(x = mixture_sample, Distribution = "Mixture")

# Combine the data frames
df_combined <- rbind(df1, df2, df_mixture)

# Plot histograms for the components and the mixture in a grid
p <- ggplot(df_combined, aes(x = x)) +
  geom_histogram(aes(y = ..density..), bins = 30, fill = "skyblue", color = "black", alpha = 0.7) +
  facet_grid(~ Distribution) + 
  labs(title = "Histograms for Burr Distribution Components and Mixture", x = "x", y = "Density") +
  theme_minimal()

# Display the grid of histograms
# p

# Define the Burr CDF function and mixture CDF for two Burr distributions
burr_cdf <- function(x, alpha, theta, gamma) {
  1 - (1 + (x / theta)^gamma)^(-alpha)
}

pburr_mixture <- function(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2) {
  pi1 * burr_cdf(q, alpha1, theta1, gamma1) + pi2 * burr_cdf(q, alpha2, theta2, gamma2)
}

# Parameters for the null and alternative Burr mixture models
alpha1 <- 0.207175; theta1 <- 1.236993; gamma1 <- 7.047898; pi1 <- 0.397634
alpha2 <- 0.028161; theta2 <- 0.856898; gamma2 <- 50.277542; pi2 <- 1 - pi1

alt_alpha1 <- 0.2; alt_theta1 <- 1.2; alt_gamma1 <- 7.1
alt_alpha2 <- 0.02; alt_theta2 <- 0.9; alt_gamma2 <- 50.4

# Function to generate samples from the null and alternative models
generate_burr_mixture_samples <- function(n, alpha1, gamma1, theta1, pi1, alpha2, gamma2, theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  ifelse(component == 1, rburr(n, alpha1, theta1, gamma1), rburr(n, alpha2, theta2, gamma2))
}

generate_alternative_samples <- function(n, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2) {
  component <- rbinom(n, 1, pi1)
  ifelse(component == 1, rburr(n, alt_alpha1, alt_theta1, alt_gamma1), rburr(n, alt_alpha2, alt_theta2, alt_gamma2))
}

# Simulation settings
n_sims <- 2000  # Number of simulations
alpha_values <- c(0.01, 0.05, 0.1)  # Significance levels
step_size <- 10  # Increment in sample size

# Initialize a list to store power curve data for each alpha
power_curves <- list()

# Loop through each alpha value to compute the power curve
for (alpha in alpha_values) {
  
  # Initialize starting sample size, power, and vectors to store sample sizes and power values
  sample_size <- 10
  power <- 0
  sample_sizes <- c()
  power_values <- c()
  
  # Increment sample size until power reaches 1
  while (power < 1) {
    power_count <- 0
    
    # Power Simulation: Alternative model
    for (i in 1:n_sims) {
      samples_alt <- generate_alternative_samples(sample_size, alt_alpha1, alt_gamma1, alt_theta1, pi1, alt_alpha2, alt_gamma2, alt_theta2, pi2)
      ad_test_alt <- ADGofTest::ad.test(samples_alt, function(q) pburr_mixture(q, alpha1, theta1, gamma1, alpha2, theta2, gamma2, pi1, pi2))
      if (ad_test_alt$p.value < alpha) {
        power_count <- power_count + 1
      }
    }
    
    # Calculate Power for the current sample size
    power <- power_count / n_sims
    
    # Store the sample size and power values
    sample_sizes <- c(sample_sizes, sample_size)
    power_values <- c(power_values, power)
    
    # Increment sample size if power is less than 1
    if (power < 1) {
      sample_size <- sample_size + step_size
    }
  }
  
  # Store the results for the current alpha value in the list
  power_curves[[paste0("alpha_", alpha)]] <- data.frame(Sample_Size = sample_sizes, Power = power_values)
  
  # Print the minimum sample size where power reaches 1
  min_sample_size_power_1 <- sample_size
  cat("\nMinimum sample size where power reaches 1 for alpha =", alpha, ":", min_sample_size_power_1, "\n")
}

# Plot the Power curves for each alpha
colors <- c("blue", "purple", "green")
plot(NULL, xlim=c(10, max(unlist(lapply(power_curves, function(df) df$Sample_Size)))), 
     ylim=c(0, 1), xlab="Sample Size", ylab="Power")

for (i in seq_along(alpha_values)) {
  alpha <- alpha_values[i]
  power_data <- power_curves[[paste0("alpha_", alpha)]]
  lines(power_data$Sample_Size, power_data$Power, col=colors[i], type="l", lwd=2)
  abline(h=1, col="red", lty=2)  # Reference line for Power = 1
}

legend("bottomright", legend=paste("Alpha =", alpha_values), col=colors, lwd=2)

power_curves_AD <- power_curves  # Save AD results