rm(list=ls())
# Load the necessary library
library(ltmix)
library(ReIns)
library(grid)
data(secura)
data <- secura$size
library(SMPracticals) 
truncation_point <- 1.2e6  # Replace with your truncation point if applicable

set.seed(123456789)
# Load necessary libraries
library(ggplot2)
library(gridExtra)

# Parameters for the 1-component lognormal distribution
mu <- 14.3258849  # Mean of the log-transformed data
sigma <- 0.5014714      # Standard deviation of the log-transformed data

# Lognormal PDF function
lognormal_pdf <- function(x, mu, sigma) {
  dlnorm(x, meanlog = mu, sdlog = sigma)
}

# Truncated Lognormal PDF
truncated_lognormal_pdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         lognormal_pdf(x, mu, sigma) / (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Truncated Lognormal CDF
truncated_lognormal_cdf <- function(x, mu, sigma, truncation_point) {
  ifelse(x < truncation_point, 0,
         (plnorm(x, meanlog = mu, sdlog = sigma) - plnorm(truncation_point, meanlog = mu, sdlog = sigma)) /
           (1 - plnorm(truncation_point, meanlog = mu, sdlog = sigma)))
}

# Function to generate random samples from the truncated lognormal distribution
generate_truncated_lognormal_samples <- function(n, mu, sigma, truncation_point) {
  samples <- rlnorm(n, meanlog = mu, sdlog = sigma)
  samples <- samples[samples >= truncation_point]
  while (length(samples) < n) {
    new_samples <- rlnorm(n - length(samples), meanlog = mu, sdlog = sigma)
    samples <- c(samples, new_samples[new_samples >= truncation_point])
  }
  return(samples)
}

# Simulation settings
sample_sizes <- c(10, 100, 500, 1000, 2000, 2500)
n_sims <- 2000
alpha_level <- 0.05

# Create lists to store plots
plots_null <- list()
plots_alt <- list()

# Loop through each sample size
for (sample_size in sample_sizes) {
  # Initialize vectors to store p-values
  p_values_null <- numeric(n_sims)
  p_values_alt <- numeric(n_sims)
  
  # Null hypothesis p-value simulations
  for (i in 1:n_sims) {
    samples_null <- generate_truncated_lognormal_samples(sample_size, mu, sigma, truncation_point)
    ad_test_null <- ADGofTest::ad.test(samples_null, function(q) truncated_lognormal_cdf(q, mu, sigma, truncation_point))
    p_values_null[i] <- ad_test_null$p.value
  }
  
  # Alternative hypothesis p-value simulations (slightly modified parameters)
  alt_mu <- 14  # Slightly shifted mean
  alt_sigma <- 1     # Slightly increased standard deviation
  
  for (i in 1:n_sims) {
    samples_alt <- generate_truncated_lognormal_samples(sample_size, alt_mu, alt_sigma, truncation_point)
    ad_test_alt <- ADGofTest::ad.test(samples_alt, function(q) truncated_lognormal_cdf(q, mu, sigma, truncation_point))
    p_values_alt[i] <- ad_test_alt$p.value
  }
  
  # Convert p-values to data frames for ggplot
  df_pvalues_null <- data.frame(p_value = p_values_null)
  df_pvalues_alt <- data.frame(p_value = p_values_alt)
  
  # Create histogram for null hypothesis
  p_null <- ggplot(df_pvalues_null, aes(x = p_value)) +
    geom_histogram(bins = 30, fill = "lightblue", color = "black", alpha = 0.7) +
    geom_vline(xintercept = alpha_level, color = "red", size = 1) +
    labs(subtitle = paste("n =", sample_size),
         x = "P-Value",
         y = "Frequency") +
    theme_minimal() +
    theme(panel.grid = element_blank(),
          axis.title = element_blank())
  
  
  # Create histogram for alternative hypothesis
  p_alt <- ggplot(df_pvalues_alt, aes(x = p_value)) +
    geom_histogram(bins = 30, fill = "lightgreen", color = "black", alpha = 0.7) +
    geom_vline(xintercept = alpha_level, color = "red", size = 1) +
    labs(subtitle = paste("n =", sample_size),
         x = "P-Value",
         y = "Frequency") +
    theme_minimal() +
    theme(panel.grid = element_blank(),
          axis.title = element_blank())
  
  # Store the plots in lists
  plots_null[[as.character(sample_size)]] <- p_null
  plots_alt[[as.character(sample_size)]] <- p_alt
}

# For null plots
grid.arrange(
  arrangeGrob(grobs = plots_null, ncol = 2, nrow = 3),
  top = textGrob("AD", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Frequency", rot = 90, gp = gpar(fontsize = 13))
)


# For alternative plots
grid.arrange(
  arrangeGrob(grobs = plots_alt, ncol = 2, nrow = 3),
  top = textGrob("AD", gp = gpar(fontsize = 16, fontface = "bold")),
  bottom = textGrob("P-Value", gp = gpar(fontsize = 13)),
  left = textGrob("Frequency", rot = 90, gp = gpar(fontsize = 13))
)
