rm(list = ls())
# Load the necessary library
library(ltmix)
library(ReIns)
library(grid)
data(secura)
data <- secura$size
library(SMPracticals) 
truncation_point <- 1.2e6  # Replace with your truncation point if applicable

set.seed(123456789)

# Fit a 1-component Lognormal mixture model
fit <- ltmm(data, G = 1, distributions = "lognormal", trunc = truncation_point)

aba <- summary(fit)

plot(fit)

# Extract the fitted parameters
parameters <- fit$Pars

# Display the parameter estimates
print(parameters)